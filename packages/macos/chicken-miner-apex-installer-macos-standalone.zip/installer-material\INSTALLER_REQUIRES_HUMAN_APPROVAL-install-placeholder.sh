#!/usr/bin/env bash
set -euo pipefail
# INSTALLER_REQUIRES_HUMAN_APPROVAL: placeholder wrapper only.
echo "Installer execution is blocked until human approval is granted for a designated test machine."
exit 2
