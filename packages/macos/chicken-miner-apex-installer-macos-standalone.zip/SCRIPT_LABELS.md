# Script Labels

Every script in this package is classified before use.

- READ_ONLY: scripts that inspect status or perform non-mutating checks.
- MUTATING_REQUIRES_HUMAN_APPROVAL: scripts that may modify files, network state, services, or host configuration.
- INSTALLER_REQUIRES_HUMAN_APPROVAL: installer or setup flow scripts. Do not execute during packaging.

## Package policy
- Platform: macOS
- Package type: installer
- Installer execution during packaging: NOT_RUN_BLOCKED_BY_POLICY
- Runtime/model/miner/service start during packaging: NOT_RUN_BLOCKED_BY_POLICY
