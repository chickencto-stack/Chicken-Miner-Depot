#!/usr/bin/env bash
set -euo pipefail
# READ_ONLY: static package inspection only. Does not start services or models.
echo "READ_ONLY smoke test: verify package manifest and graph handoff"
test -f MANIFEST.json
test -f graph_context/APEX_CODEGRAPHCONTEXT_HANDOFF.md
test -f SHA256SUMS.txt
echo "STATIC_PACKAGE_READY"
