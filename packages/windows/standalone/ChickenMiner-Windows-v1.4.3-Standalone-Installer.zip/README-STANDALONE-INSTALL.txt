﻿Chicken Miner Windows v1.4.3 standalone installer. Extract, verify SHA256SUMS.txt, then run ChKn_miner_installer_x64.exe.
