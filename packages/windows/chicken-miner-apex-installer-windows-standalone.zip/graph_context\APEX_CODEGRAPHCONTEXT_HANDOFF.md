# APEX Graph Context Handoff

## CodeGraphContext Source
- Package: CodeGraphContext
- Surface Pro 9 status: READY_FOR_LOCAL_AGENT_USE
- Active command: cgc agent-graph build
- Fallback command: python scripts\build_agent_graph.py
- Surface path: C:\Users\jrchi\Documents\Codex\2026-06-06\files-mentioned-by-the-user-pasted\CodeGraphContext
- Feature branch: build-agent-context-graph
- Active PR: https://github.com/CodeGraphContext/CodeGraphContext/pull/1128
- Feature commit: 4348f1a
- Readiness docs commit: e879795

## Windows install fallback
Run: python -m pip install -e . --no-deps
Then install needed runtime dependencies excluding kuzu if kuzu fails.

## Expected graph outputs
- .agent/graph/code_graph.json
- .agent/graph/code_graph.md
- .agent/graph/code_graph.mmd
- .agent/graph/code_graph.dot
- .agent/context_index.md
- .agent/README.md
- .agent/work_notes/README.md

## Required local-agent workflow
Before work:

    cgc agent-graph build
    Get-Content .agent\context_index.md -TotalCount 120

Agent must report:
1. Relevant graph neighborhood
2. Intended edit boundary
3. Files to avoid touching

After edits:

    cgc agent-graph build

Then write:

    .agent/work_notes/YYYYMMDD-HHMM-task-name.md

## Boundary
This handoff is included for graph-first operation only. It does not authorize runtime, deployment, installer execution, service control, GitHub publish, Docker/Kubernetes, Tailscale mutation, or secret handling.
