﻿# APEX OpenAI-Compatible Provider Config

- Base URL: http://10.0.0.27:8000/v1
- Chat endpoint: http://10.0.0.27:8000/v1/chat/completions
- Model alias: /models/26b
- Provider host: DGX Spark / spark-212f (10.0.0.27)

## API proof status
- /v1/models reachable and includes /models/26b
- /v1/chat/completions with /models/26b returns APEX_GEMMA4_26B_READY

## APEX/VAPEX values
- chat_url=http://10.0.0.27:8000/v1/chat/completions
- agent_url=http://10.0.0.27:8000/v1/chat/completions
- model_chat=/models/26b
- model_agent=/models/26b
