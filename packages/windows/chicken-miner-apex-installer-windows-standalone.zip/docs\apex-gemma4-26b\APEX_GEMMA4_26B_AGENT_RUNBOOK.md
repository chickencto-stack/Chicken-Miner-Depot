﻿# APEX Gemma4 26B Agent Runbook

- Endpoint: http://10.0.0.27:8000/v1/chat/completions
- Model alias: /models/26b
- OpenAI-compatible base: http://10.0.0.27:8000/v1
- OpenWebUI URL: http://10.0.0.27:3000
- OpenWebUI internal provider target (expected): http://gemma-vllm:8000/v1

## APEX config values
- chat_url=http://10.0.0.27:8000/v1/chat/completions
- agent_url=http://10.0.0.27:8000/v1/chat/completions
- model_chat=/models/26b
- model_agent=/models/26b

## API test
```powershell
curl.exe -sS http://10.0.0.27:8000/v1/models
```

```powershell
$body = @{
  model = "/models/26b"
  messages = @(@{ role = "user"; content = "Reply with APEX_GEMMA4_26B_READY only." })
  max_tokens = 16
} | ConvertTo-Json -Depth 5
Invoke-RestMethod -Uri "http://10.0.0.27:8000/v1/chat/completions" -Method Post -ContentType "application/json" -Body $body
```

## UI chat test phrase
- Prompt: Reply with APEX_GEMMA4_26B_CHAT_READY only.
- Expected: APEX_GEMMA4_26B_CHAT_READY

## MCP status
- Testdrive currently blocked by machine_auth_required until non-interactive SBX machine credentials are configured.

## Docker status
- Docker daemon unavailable in this host session (`//./pipe/dockerDesktopLinuxEngine` missing).

## Blocked actions
- LabDeploy Media execution
- installer execution
- physical media movement
- production deployment
- Houston promotion
- Kubernetes run
- miner runtime
- GitHub release
- Tailscale mutation
- firewall mutation
- service control
- secret access
- purchase authorization
- SUI material

## One next action
- Complete human OpenWebUI login at http://10.0.0.27:3000 and run the /models/26b UI chat phrase proof.
