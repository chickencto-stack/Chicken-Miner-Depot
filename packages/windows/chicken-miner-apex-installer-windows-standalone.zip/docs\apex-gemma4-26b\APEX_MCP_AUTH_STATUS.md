﻿# APEX MCP Auth Status

- Command: npm run vapex:mcp:testdrive
- Current result: machine_auth_required: non-interactive SBX machine credentials are not configured.
- State: auth-blocked

Policy:
- Do not bypass machine auth
- Do not expose secrets
