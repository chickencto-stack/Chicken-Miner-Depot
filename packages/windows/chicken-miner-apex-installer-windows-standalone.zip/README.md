# chicken-miner-apex-installer-windows-standalone

## Purpose
Static Chicken Miner Depot Windows installer package for APEX/Gemma4 26B testing with CodeGraphContext handoff.

## Graph-first workflow
1. Run `cgc agent-graph build` before changing package contents.
2. Read `.agent/context_index.md` or this package's `graph_context/APEX_CODEGRAPHCONTEXT_HANDOFF.md`.
3. Report relevant graph neighborhood, intended edit boundary, and files to avoid touching.
4. After edits, run `cgc agent-graph build` again.
5. Write `.agent/work_notes/YYYYMMDD-HHMM-task-name.md`.

Expected graph outputs: `.agent/graph/code_graph.json` and `.agent/context_index.md`.

Known Windows fallback: `python -m pip install -e . --no-deps`, then install needed runtime dependencies excluding kuzu if kuzu fails.

## Smoke-test instructions
Use read-only smoke-test scripts where present. Do not run installers or mutating scripts without human approval.

## Expected success markers
- APEX_GEMMA4_26B_CHAT_READY when an approved chat proof is run.
- OpenWebUI /models/26b UI proof ready from current accepted state.
- Static package verification passes manifest, SHA256, and secret scan checks.

## Known limitations
- GitHub Chicken-Miner-Depot push remains blocked by repo permissions.
- NUCI8 conflict remains in parallel.
- Installer execution was not run during packaging.
- No secrets, tokens, cookies, private keys, or .env secret values are included.

## Script labels
See `SCRIPT_LABELS.md` before running any script.
