#Requires -RunAsAdministrator
[CmdletBinding()]
param(
    [string]$PackageRoot = $PSScriptRoot,
    [switch]$SkipExecutionPolicyBypass
)


Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# CADET: Safe initialization of $ArtifactPaths before any use
if (-not (Get-Variable -Name ArtifactPaths -Scope Script -ErrorAction SilentlyContinue)) {
    $script:ArtifactPaths = [ordered]@{
        ComplianceInventory = ''
        FleetMgrProof = ''
        ConditionState = ''
        ThreadControl = ''
        RuntimeLogs = @()
        UsbEvidencePath = ''
        OneDriveEvidencePath = ''
    }
}

$runId = Get-Date -Format 'yyyyMMdd-HHmmss'
$logRoot = 'C:\ProgramData\LabDeploy'
New-Item -ItemType Directory -Path $logRoot -Force | Out-Null
$logPath = Join-Path $logRoot ("run-this-first-{0}-{1}.log" -f $env:COMPUTERNAME, $runId)
$stateRoot = Join-Path $logRoot 'FleetMGR-State'
New-Item -ItemType Directory -Path $stateRoot -Force | Out-Null
$evidenceHelperPath = Join-Path $PSScriptRoot 'FleetMGR-Evidence-Export.ps1'
if (Test-Path -LiteralPath $evidenceHelperPath) { . $evidenceHelperPath }

$outcome = 'UNKNOWN'
$errorText = ''
$evidenceExported = $false
$heartbeatSourceId = "RunThisFirst-Heartbeat-$runId"
$runnerOutcomePath = Join-Path $logRoot ("run-this-first-outcome-{0}-{1}.json" -f $env:COMPUTERNAME, $runId)
$childStdoutPath = Join-Path $logRoot ("run-this-first-child-{0}-{1}.stdout.log" -f $env:COMPUTERNAME, $runId)
$childStderrPath = Join-Path $logRoot ("run-this-first-child-{0}-{1}.stderr.log" -f $env:COMPUTERNAME, $runId)
$childTimeoutSeconds = 1800
$childProcessStarted = $false
$childProcessId = $null
$childExitCode = $null
$childTimedOut = $false
$childDurationSeconds = $null
$childStartUtc = $null
$childEndUtc = $null
$childFinalStatusPath = Join-Path $logRoot ("fleetmgr-chknmnr-final-status-{0}-{1}.json" -f $env:COMPUTERNAME, $runId)
$childFinalStatusPresent = $false
$step6EvidencePresent = $false
$step7EvidencePresent = $false

function Write-LogLine([string]$Level, [string]$Message) {
    $line = "[{0}] [{1}] {2}" -f (Get-Date -Format 's'), $Level, $Message
    Add-Content -LiteralPath $logPath -Value $line
}

function Write-Info([string]$Message) {
    Write-Host "[INFO] $Message" -ForegroundColor Cyan
    Write-LogLine -Level 'INFO' -Message $Message
}
function Write-Ok([string]$Message) {
    Write-Host "[OK]   $Message" -ForegroundColor Green
    Write-LogLine -Level 'OK' -Message $Message
}
function Write-WarnMsg([string]$Message) {
    Write-Host "[WARN] $Message" -ForegroundColor Yellow
    Write-LogLine -Level 'WARN' -Message $Message
}
function Write-Fail([string]$Message) {
    Write-Host "[FAIL] $Message" -ForegroundColor Red
    Write-LogLine -Level 'FAIL' -Message $Message
}

function Get-RunnerOneDriveRoot {
    $candidates = @(
        (Join-Path $env:USERPROFILE 'OneDrive - Securement'),
        (Join-Path $env:USERPROFILE 'OneDrive'),
        $env:OneDriveCommercial,
        $env:OneDrive
    ) | Where-Object { $_ }

    foreach ($path in ($candidates | Select-Object -Unique)) {
        if (Test-Path -LiteralPath $path) { return $path }
    }

    return $null
}

function Invoke-RunnerHeartbeatSync {
    $root = Get-RunnerOneDriveRoot
    if (-not $root) { return }

    $dest = Join-Path $root ("FleetMGR-Evidence\\LIVE\\{0}\\Run-This-First" -f $env:COMPUTERNAME)
    New-Item -ItemType Directory -Path $dest -Force | Out-Null

    foreach ($artifact in @(
        $logPath,
        $runnerOutcomePath,
        $childStdoutPath,
        $childStderrPath,
        'C:\ProgramData\LabDeploy\fleetmgr-chknmnr.log',
        'C:\ProgramData\LabDeploy\FleetMGR-State\fleetmgr-proof-latest.json',
        'C:\ProgramData\LabDeploy\installer-diagnostic.txt'
    )) {
        if ($artifact -and (Test-Path -LiteralPath $artifact)) {
            Copy-Item -LiteralPath $artifact -Destination $dest -Force -ErrorAction SilentlyContinue
        }
    }

    "heartbeat $(Get-Date -Format o)" | Set-Content -LiteralPath (Join-Path $dest 'heartbeat.txt') -Encoding UTF8
    if (Get-Command Invoke-FleetMgrOneDriveSyncNow -ErrorAction SilentlyContinue) {
        Invoke-FleetMgrOneDriveSyncNow -EvidencePath $dest -OneDriveRoot $root | Out-Null
    }
}

function Start-RunnerHeartbeat {
    Register-ObjectEvent -InputObject (New-Object System.Timers.Timer -Property @{ Interval = 60000; AutoReset = $true; Enabled = $true }) -EventName Elapsed -SourceIdentifier $heartbeatSourceId -Action {
        try { Invoke-RunnerHeartbeatSync } catch {}
    } | Out-Null
    Invoke-RunnerHeartbeatSync
    Write-Info 'Heartbeat sync enabled (60s).'
}

function Stop-RunnerHeartbeat {
    Unregister-Event -SourceIdentifier $heartbeatSourceId -ErrorAction SilentlyContinue
    Get-Job -Name $heartbeatSourceId -ErrorAction SilentlyContinue | Remove-Job -Force -ErrorAction SilentlyContinue
}

function Write-RunnerOutcomeRecord {
    $record = [ordered]@{
        RunId = $runId
        Computer = $env:COMPUTERNAME
        TimestampUtc = (Get-Date).ToUniversalTime().ToString('o')
        Outcome = $outcome
        ErrorText = $errorText
        ChildProcessStarted = [bool]$childProcessStarted
        ChildProcessId = $childProcessId
        ChildStdoutPath = $childStdoutPath
        ChildStderrPath = $childStderrPath
        ChildExitCode = $childExitCode
        ChildTimedOut = [bool]$childTimedOut
        ChildDurationSeconds = $childDurationSeconds
        ChildStartUtc = if ($childStartUtc) { $childStartUtc.ToUniversalTime().ToString('o') } else { $null }
        ChildEndUtc = if ($childEndUtc) { $childEndUtc.ToUniversalTime().ToString('o') } else { $null }
        ChildFinalStatusPath = $childFinalStatusPath
        ChildFinalStatusPresent = [bool]$childFinalStatusPresent
        Step6EvidencePresent = [bool]$step6EvidencePresent
        Step7EvidencePresent = [bool]$step7EvidencePresent
        ParentLogPath = $logPath
        PackageRoot = $PackageRoot
    }
    ($record | ConvertTo-Json -Depth 6) | Set-Content -LiteralPath $runnerOutcomePath -Encoding UTF8
}

function Invoke-RunnerEvidenceExport {
    Stop-RunnerHeartbeat
    if ($evidenceExported) { return }
    if (Get-Command Invoke-FleetMgrEvidenceExport -ErrorAction SilentlyContinue) {
        $allArtifacts = New-Object System.Collections.Generic.List[string]
        foreach ($artifact in @(
            $runnerOutcomePath,
            $childStdoutPath,
            $childStderrPath,
            $childFinalStatusPath,
            'C:\ProgramData\LabDeploy\fleetmgr-chknmnr.log',
            'C:\ProgramData\LabDeploy\FleetMGR-State\fleetmgr-proof-latest.json',
            'C:\ProgramData\LabDeploy\installer-diagnostic.txt'
        )) {
            if (-not [string]::IsNullOrWhiteSpace([string]$artifact)) {
                [void]$allArtifacts.Add([string]$artifact)
            }
        }
        $exportResult = Invoke-FleetMgrEvidenceExport -ScriptLabel 'Run-This-First' -RunId $runId -Outcome $outcome -ErrorText $errorText -LogPaths @($logPath) -ArtifactPaths @($allArtifacts) -StateRoot $stateRoot -ExtraMetadata @{ package_root = $PackageRoot; precheck_failed_count = $failedChecks.Count }
        if ($exportResult -and $exportResult.Destination) {
            Write-Ok "SYNC_TARGET=$($exportResult.Destination)"
        }
        if ($exportResult -and $exportResult.OneDriveStatus -eq 'UNAVAILABLE') {
            $reason = if ($exportResult.OneDriveReason) { $exportResult.OneDriveReason } else { 'unknown reason' }
            Write-WarnMsg "OneDriveEvidenceStatus=UNAVAILABLE ($reason)"
        }
    }
    $script:evidenceExported = $true
}

function Finalize-RunnerAndExit {
    param([int]$ExitCode)
    try { Write-RunnerOutcomeRecord } catch {}
    try { Invoke-RunnerEvidenceExport } catch {}
    exit $ExitCode
}

function Assert-Admin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'This script must be run in an elevated PowerShell session (Run as Administrator).'
    }
}

function Resolve-ExistingPath {
    param([string[]]$Candidates)
    foreach ($candidate in $Candidates) {
        if ($candidate -and (Test-Path -LiteralPath $candidate)) { return $candidate }
    }
    return $null
}

Write-Host ''
Write-Host '=== FleetMGR Precheck Runner ===' -ForegroundColor White
Write-Host "Machine: $env:COMPUTERNAME" -ForegroundColor White
Write-Host "Started: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -ForegroundColor White
Write-Host ''

$failedChecks = New-Object System.Collections.Generic.List[string]

try {
    Assert-Admin
    Write-Ok 'Elevated session confirmed.'
}
catch {
    $outcome = 'FAIL'
    $errorText = [string]$_
    Write-Fail $_
    Finalize-RunnerAndExit -ExitCode 1
}

if (-not $SkipExecutionPolicyBypass) {
    Set-ExecutionPolicy Bypass -Scope Process -Force
    Write-Ok 'Execution policy set to Bypass for this process.'
}
else {
    Write-WarnMsg 'SkipExecutionPolicyBypass requested. Leaving execution policy unchanged.'
}

Write-Info "PSScriptRoot: '$PSScriptRoot'"
Write-Info "PackageRoot (param): '$PackageRoot'"

if (-not $PackageRoot) {
    if ($PSScriptRoot) {
        $PackageRoot = $PSScriptRoot
        Write-Info "PackageRoot was empty; recovered from PSScriptRoot: '$PackageRoot'"
    } else {
        $outcome = 'FAIL'
        $errorText = 'PackageRoot and PSScriptRoot are both empty. Run via: powershell.exe -File "<full-path>\Run This First.ps1"'
        Write-Fail $errorText
        Finalize-RunnerAndExit -ExitCode 1
    }
}

if (-not (Test-Path -LiteralPath $PackageRoot)) {
    $outcome = 'FAIL'
    $errorText = "Package root not found: $PackageRoot"
    Write-Fail "Package root not found: $PackageRoot"
    Finalize-RunnerAndExit -ExitCode 1
}

try {
    $PackageRoot = (Resolve-Path -LiteralPath $PackageRoot).Path
}
catch {
    $outcome = 'FAIL'
    $errorText = "Resolve-Path failed for '$PackageRoot': $_"
    Write-Fail $errorText
    Finalize-RunnerAndExit -ExitCode 1
}

try {
    Set-Location -LiteralPath $PackageRoot
}
catch {
    $outcome = 'FAIL'
    $errorText = "Set-Location failed for '$PackageRoot': $_"
    Write-Fail $errorText
    Finalize-RunnerAndExit -ExitCode 1
}

Write-Ok "Using package root: $PackageRoot"

try {
    Start-RunnerHeartbeat
}
catch {
    Write-WarnMsg "Heartbeat init failed (non-fatal): $_"
}

$requiredFiles = @(
    'FleetMGR-ChknMNR.ps1',
    '05-ChknMiner-Install.ps1',
    'DEPLOY-CONFIG.json',
    'ZTPkg.msi',
    'cybercrucible-installer-cli.exe'
)

foreach ($file in $requiredFiles) {
    $fullPath = Join-Path $PackageRoot $file
    if (Test-Path -LiteralPath $fullPath) {
        Write-Ok "Found $file"
    }
    else {
        $failedChecks.Add("Missing required file: $file") | Out-Null
        Write-Fail "Missing $file"
    }
}

$minerSource = Resolve-ExistingPath -Candidates @(
    (Join-Path $PackageRoot 'secminer.zip'),
    (Join-Path $PackageRoot 'ChknMiner-1.4.3.zip'),
    (Join-Path $PackageRoot 'ChKn_miner_installer_x64.exe')
)

if ($minerSource) {
    Write-Ok "Miner source resolved: $minerSource"
}
else {
    $failedChecks.Add('Missing miner payload (secminer.zip, ChknMiner-1.4.3.zip, or ChKn_miner_installer_x64.exe).') | Out-Null
    Write-Fail 'Miner payload is missing.'
}

$oneDriveRoot = Resolve-ExistingPath -Candidates @(
    (Join-Path $env:USERPROFILE 'OneDrive - Securement'),
    (Join-Path $env:USERPROFILE 'OneDrive'),
    $env:OneDriveCommercial,
    $env:OneDrive
)
if ($oneDriveRoot) {
    Write-Ok "OneDrive root found: $oneDriveRoot"
}
else {
    Write-WarnMsg 'OneDrive root not found. Installer can still run, but evidence sync may be delayed.'
}

if ($failedChecks.Count -gt 0) {
    $outcome = 'FAIL'
    $errorText = 'Precheck failed.'
    Write-Host ''
    Write-Fail 'Precheck failed. Fix the following and rerun:'
    foreach ($msg in $failedChecks) { Write-Fail " - $msg" }
    Finalize-RunnerAndExit -ExitCode 1
}

Write-Host ''
Write-Ok 'Precheck passed. Launching FleetMGR installer...'
Write-Info "Command: powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$((Join-Path $PackageRoot 'FleetMGR-ChknMNR.ps1'))`" -ChknMinerSource `"$minerSource`""

$fleetScript = Join-Path $PackageRoot 'FleetMGR-ChknMNR.ps1'
$fleetArgs = @(
    '-NoProfile',
    '-ExecutionPolicy', 'Bypass',
    '-File', $fleetScript,
    '-ChknMinerSource', $minerSource
)
$childStartUtc = Get-Date
$childProcessStarted = $true
Write-Info "ChildStdoutPath=$childStdoutPath"
Write-Info "ChildStderrPath=$childStderrPath"
$fleetProc = Start-Process -FilePath 'powershell.exe' -ArgumentList $fleetArgs -PassThru -NoNewWindow -RedirectStandardOutput $childStdoutPath -RedirectStandardError $childStderrPath
$childProcessId = $fleetProc.Id
Write-Info "ChildProcessStarted=True ChildProcessId=$childProcessId TimeoutSeconds=$childTimeoutSeconds"

Wait-Process -Id $fleetProc.Id -Timeout $childTimeoutSeconds -ErrorAction SilentlyContinue | Out-Null
$fleetProc.Refresh()
$childEndUtc = Get-Date
$childDurationSeconds = [math]::Round((New-TimeSpan -Start $childStartUtc -End $childEndUtc).TotalSeconds, 3)
if ($fleetProc.HasExited) {
    $childExitCode = $fleetProc.ExitCode
} else {
    $childTimedOut = $true
    try { Stop-Process -Id $fleetProc.Id -Force -ErrorAction Stop } catch {}
    $childExitCode = 124
}
$latestChildFinal = Get-ChildItem -Path $logRoot -File -Filter ("fleetmgr-chknmnr-final-status-{0}-*.json" -f $env:COMPUTERNAME) -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if ($latestChildFinal) {
    $childFinalStatusPath = $latestChildFinal.FullName
    $childFinalStatusPresent = $true
}
if (-not (Test-Path -LiteralPath $childStderrPath)) {
    '' | Set-Content -LiteralPath $childStderrPath -Encoding UTF8
}
if ($null -eq $childExitCode) {
    $childExitCode = 125
    $errorText = 'FleetMGR installer child process returned a missing exit code.'
}
$proofLatest = 'C:\ProgramData\LabDeploy\FleetMGR-State\fleetmgr-proof-latest.json'
if (Test-Path -LiteralPath $proofLatest) {
    try {
        $proofObj = Get-Content -LiteralPath $proofLatest -Raw | ConvertFrom-Json -ErrorAction Stop
        $proofStages = @($proofObj.Stages)
        $step6EvidencePresent = [bool](@($proofStages | Where-Object { $_.Step -match 'Step6-UpdaterAgent|Updater-Agent' }).Count -gt 0)
        $step7EvidencePresent = [bool](
            (@($proofStages | Where-Object { $_.Step -match 'Step7-BotRules|BotRules-Task' }).Count -gt 0) -and
            (@($proofStages | Where-Object { $_.Step -match 'Step7-ConditionMonitor|ConditionMonitor-Task' }).Count -gt 0)
        )
    } catch {}
}
$exitCode = $childExitCode

Write-Host ''
if ($childTimedOut) {
    $outcome = 'FAIL'
    $errorText = "FleetMGR installer child process timed out after $childTimeoutSeconds seconds"
    Write-Fail $errorText
}
elseif ($exitCode -eq 0) {
    if (-not $childFinalStatusPresent -or -not $step6EvidencePresent -or -not $step7EvidencePresent) {
        $outcome = 'FAIL'
        $errorText = 'FleetMGR installer exited 0 but required final-status/Step6/Step7 evidence is missing.'
        Write-Fail $errorText
        $exitCode = 126
    } else {
        $outcome = 'PASS'
        Write-Ok 'FleetMGR installer completed successfully.'
    }
}
else {
    $outcome = 'FAIL'
    $errorText = "FleetMGR installer exited with code $exitCode"
    Write-Fail "FleetMGR installer exited with code $exitCode"
}

Finalize-RunnerAndExit -ExitCode $exitCode
