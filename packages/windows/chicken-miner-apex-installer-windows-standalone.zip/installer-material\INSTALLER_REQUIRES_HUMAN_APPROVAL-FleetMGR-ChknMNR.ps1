#Requires -RunAsAdministrator
param(
    [switch]$SkipZT,
    [switch]$SkipCC,
    [switch]$SkipRemote,
    [switch]$SkipMiner,
    [switch]$SkipAgent,
    [switch]$SkipConditionMonitor,
    [string]$ZTPkgPath,
    [string]$CCInstallerPath,
    [string]$ChknMinerSource,
    [string]$OneDriveShareUrl
)
$ErrorActionPreference = 'Stop'
$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$RunId = Get-Date -Format 'yyyyMMdd-HHmmss'
$LogPath = "C:\ProgramData\LabDeploy\fleetmgr-chknmnr-$($env:COMPUTERNAME)-$RunId.log"
$LegacyLogPath = 'C:\ProgramData\LabDeploy\fleetmgr-chknmnr.log'
$CheckpointPath = "C:\ProgramData\LabDeploy\fleetmgr-chknmnr-checkpoints-$($env:COMPUTERNAME)-$RunId.jsonl"
$FinalStatusPath = "C:\ProgramData\LabDeploy\fleetmgr-chknmnr-final-status-$($env:COMPUTERNAME)-$RunId.json"
$LatestFinalStatusPath = 'C:\ProgramData\LabDeploy\fleetmgr-chknmnr-final-status-latest.json'
$script:FinalStatusWritten = $false
New-Item -ItemType Directory -Path (Split-Path $LogPath -Parent) -Force | Out-Null
function Write-Log {
    param([string]$Message,[string]$Level='INFO')
    $line='[{0}] [{1}] {2}' -f (Get-Date -Format s),$Level,$Message
    Add-Content -Path $LogPath -Value $line
    Add-Content -Path $LegacyLogPath -Value $line
    if($Level -ne 'DEBUG'){Write-Host $line}
}
function Step-Banner {
    param([string]$Text)
    Write-Checkpoint -Stage ("BANNER: " + $Text)
    Write-Log ''
    Write-Log ('==== ' + $Text + ' ====')
}

function Convert-ToEvidenceSafeValue {
    param([object]$Value)

    if ($null -eq $Value) { return $null }
    if ($Value -is [string] -or $Value -is [bool] -or $Value -is [int] -or $Value -is [long] -or $Value -is [double] -or $Value -is [decimal]) {
        return $Value
    }
    if ($Value -is [datetime]) { return $Value.ToString('o') }
    if ($Value -is [System.Management.Automation.ErrorRecord]) {
        return [ordered]@{
            ExceptionType = if ($Value.Exception) { $Value.Exception.GetType().FullName } else { 'ErrorRecord' }
            Message = if ($Value.Exception) { $Value.Exception.Message } else { [string]$Value }
            CategoryInfo = [string]$Value.CategoryInfo
            FullyQualifiedErrorId = [string]$Value.FullyQualifiedErrorId
            ScriptStackTrace = if ($Value.ScriptStackTrace) { [string]$Value.ScriptStackTrace } else { $null }
            InvocationInfo = [ordered]@{
                ScriptName = if ($Value.InvocationInfo) { [string]$Value.InvocationInfo.ScriptName } else { $null }
                ScriptLineNumber = if ($Value.InvocationInfo) { $Value.InvocationInfo.ScriptLineNumber } else { $null }
                OffsetInLine = if ($Value.InvocationInfo) { $Value.InvocationInfo.OffsetInLine } else { $null }
                Line = if ($Value.InvocationInfo) { [string]$Value.InvocationInfo.Line } else { $null }
            }
        }
    }
    if ($Value -is [System.Exception]) {
        return [ordered]@{
            Type = $Value.GetType().FullName
            Message = $Value.Message
            HResult = $Value.HResult
            ScriptStackTrace = if ($Value.PSObject.Properties['ScriptStackTrace']) { [string]$Value.ScriptStackTrace } else { $null }
            Inner = if ($Value.InnerException) { (Convert-ToEvidenceSafeValue -Value $Value.InnerException) } else { $null }
        }
    }
    if ($Value -is [System.Collections.IDictionary]) {
        $out = [ordered]@{}
        foreach ($key in $Value.Keys) {
            $out[[string]$key] = Convert-ToEvidenceSafeValue -Value $Value[$key]
        }
        return $out
    }
    if ($Value -is [System.Collections.IEnumerable] -and -not ($Value -is [string])) {
        $arr = @()
        foreach ($item in $Value) { $arr += (Convert-ToEvidenceSafeValue -Value $item) }
        return $arr
    }
    if ($Value.PSObject -and $Value.PSObject.Properties) {
        $obj = [ordered]@{}
        foreach ($prop in $Value.PSObject.Properties) {
            $obj[[string]$prop.Name] = Convert-ToEvidenceSafeValue -Value $prop.Value
        }
        return $obj
    }
    return [string]$Value
}

function Get-NormalizedResultObject {
    $normalized = @()
    foreach ($entry in @($results.ToArray())) {
        $normalized += [pscustomobject]@{
            Step = [string]$entry.Step
            Success = [bool]$entry.Success
            Detail = Convert-ToEvidenceSafeValue -Value $entry.Detail
            Timestamp = [string]$entry.Timestamp
        }
    }
    return $normalized
}

function Write-Checkpoint {
    param(
        [string]$Stage,
        [object]$Detail = $null
    )
    try {
        $entry = [ordered]@{
            RunId = $RunId
            TimestampUtc = (Get-Date).ToUniversalTime().ToString('o')
            Stage = $Stage
            Detail = Convert-ToEvidenceSafeValue -Value $Detail
        }
        Add-Content -LiteralPath $CheckpointPath -Value ($entry | ConvertTo-Json -Compress -Depth 8)
    } catch {}
}

function Write-FinalStatusRecord {
    param(
        [string]$Outcome,
        [int]$ExitCode,
        [string]$ErrorText = ''
    )
    if ($script:FinalStatusWritten) { return }
    $status = [ordered]@{
        RunId = $RunId
        Computer = $env:COMPUTERNAME
        TimestampUtc = (Get-Date).ToUniversalTime().ToString('o')
        Outcome = $Outcome
        ExitCode = $ExitCode
        ErrorText = $ErrorText
        LogPath = $LogPath
        CheckpointPath = $CheckpointPath
        ResultCount = @($results).Count
        HasFailure = [bool](@($results | Where-Object { -not $_.Success }).Count -gt 0)
    }
    $safeStatus = Convert-ToEvidenceSafeValue -Value $status
    $json = $safeStatus | ConvertTo-Json -Depth 8
    $json | Set-Content -LiteralPath $FinalStatusPath -Encoding UTF8
    $json | Set-Content -LiteralPath $LatestFinalStatusPath -Encoding UTF8
    $script:FinalStatusWritten = $true
}

function Invoke-ZeroTouchPortalCommand {
    param(
        [Parameter(Mandatory=$true)][string]$MsiPath,
        [string]$SiteTokenPath
    )
    if (-not (Test-Path -LiteralPath $MsiPath)) { throw "ZTPkg.msi not found at: $MsiPath" }
    $tokenResolution = Resolve-SiteToken -OperatorProvidedPath $SiteTokenPath
    if ([string]::IsNullOrWhiteSpace($tokenResolution.Token)) {
        throw 'SITE_TOKEN required but unavailable. Resolve-SiteToken returned missing.'
    }
    $msiDir = Split-Path -Parent $MsiPath
    $cmd = 'cd /d "' + $msiDir + '" && ZTPkg.msi /qn SITE_TOKEN=%SITE_TOKEN% PROV=false COMPANY="Securement"'
    Write-Log 'Running exactly as ZeroTouch portal instructs, from the MSI folder:'
    Write-Log ('ZeroTouch SITE_TOKEN resolution: token_present=true source_type={0}' -f $tokenResolution.SourceType)
    Write-Log 'ZTPkg.msi /qn SITE_TOKEN=<REDACTED> PROV=false COMPANY="Securement"'
    $priorSiteToken = $env:SITE_TOKEN
    $env:SITE_TOKEN = $tokenResolution.Token
    try {
        & $env:ComSpec /d /s /c $cmd
    } finally {
        if ($null -eq $priorSiteToken) {
            Remove-Item Env:SITE_TOKEN -ErrorAction SilentlyContinue
        } else {
            $env:SITE_TOKEN = $priorSiteToken
        }
    }
    return $LASTEXITCODE
}
$configPath = Join-Path $ScriptRoot 'DEPLOY-CONFIG.json'
$cfg = if(Test-Path -LiteralPath $configPath){ Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json } else { [pscustomobject]@{} }
$RemoteVSCodeRequired = [bool]($cfg.PSObject.Properties['RemoteVSCodeRequired'] -and $cfg.RemoteVSCodeRequired)
$ZeroTouchRequired = [bool]($cfg.PSObject.Properties['ZeroTouchRequired'] -and $cfg.ZeroTouchRequired)
$OneDriveRequired = [bool]($cfg.PSObject.Properties['OneDriveRequired'] -and $cfg.OneDriveRequired)
if(-not $ZTPkgPath){ $ZTPkgPath = if($cfg.ZTPkgPath){$cfg.ZTPkgPath}else{Join-Path $ScriptRoot 'ZTPkg.msi'} }
if(-not [System.IO.Path]::IsPathRooted($ZTPkgPath)){ $ZTPkgPath = Join-Path $ScriptRoot $ZTPkgPath }
if(-not $CCInstallerPath){ $CCInstallerPath = Join-Path $ScriptRoot 'cybercrucible-installer-cli.exe' }
$ChknMinerSourceExplicit = $PSBoundParameters.ContainsKey('ChknMinerSource')
if(-not $ChknMinerSource){ $ChknMinerSource = if($cfg.ChknMinerInstallerPath){$cfg.ChknMinerInstallerPath}else{Join-Path $ScriptRoot 'ChKn_miner_installer_x64.exe'} }
if($ChknMinerSource -and -not [System.IO.Path]::IsPathRooted($ChknMinerSource)){ $ChknMinerSource = Join-Path $ScriptRoot $ChknMinerSource }
if(-not $OneDriveShareUrl -and $cfg.OneDriveShareUrl -and $cfg.OneDriveShareUrl -notlike 'PASTE_*'){ $OneDriveShareUrl = $cfg.OneDriveShareUrl }
$SiteTokenOverridePath = if($cfg.PSObject.Properties['SiteTokenPath'] -and $cfg.SiteTokenPath){ [string]$cfg.SiteTokenPath } else { $null }
$RuntimePackageRoot = 'C:\ProgramData\LabDeploy\Package'
New-Item -ItemType Directory -Path $RuntimePackageRoot -Force | Out-Null
$_criticalPayload = @('05-ChknMiner-Install.ps1','ChKn_miner_installer_x64.exe')
foreach($file in @('05-ChknMiner-Install.ps1','ChknMiner-Updater-Agent.ps1','ChknMiner-BotRules.ps1','ChknMiner-Condition-Monitor.ps1','DEPLOY-CONFIG.json','ChKn_miner_installer_x64.exe')){
    $src = Join-Path $ScriptRoot $file
    if(Test-Path -LiteralPath $src){
        Copy-Item -LiteralPath $src -Destination (Join-Path $RuntimePackageRoot $file) -Force
        Write-Log "Staged runtime package file: $file"
    } elseif($file -in $_criticalPayload) {
            $err = "PREFLIGHT FAIL: Critical payload missing from package source - cannot stage '$file'. Expected at: $src. Ensure the USB/source package contains this file before running. Aborting."
        Write-Log $err 'ERROR'
        throw $err
    } else {
        Write-Log "Runtime package source missing (non-critical): $src" 'WARN'
    }
}
Write-Checkpoint -Stage 'RUNTIME_PAYLOAD_STAGING_COMPLETE' -Detail ([ordered]@{ RuntimePackageRoot = $RuntimePackageRoot })
$RuntimeMinerInstaller = Join-Path $RuntimePackageRoot 'ChKn_miner_installer_x64.exe'
if((Test-Path -LiteralPath $RuntimeMinerInstaller) -and (-not $ChknMinerSourceExplicit)){ $ChknMinerSource = $RuntimeMinerInstaller }
$CanonicalServiceName = if($cfg.PSObject.Properties['ChknMinerServiceName'] -and $cfg.ChknMinerServiceName){ [string]$cfg.ChknMinerServiceName } else { 'ChKn_miner' }
$CanonicalConfigFileName = if($cfg.PSObject.Properties['ChknMinerCanonicalConfig'] -and $cfg.ChknMinerCanonicalConfig){ [string]$cfg.ChknMinerCanonicalConfig } else { 'config.json' }

# --- Thread-control.json consumer (next-start apply) ---
$threadControlPath = 'C:\ProgramData\LabDeploy\ChKnMiner\thread-control.json'
$threadLimitPercent = $null
if (Test-Path $threadControlPath) {
    try {
        $threadControl = Get-Content $threadControlPath -Raw | ConvertFrom-Json
        if ($threadControl.ThreadLimitPercent -is [int] -or $threadControl.ThreadLimitPercent -is [double]) {
            $threadLimitPercent = [int]$threadControl.ThreadLimitPercent
            Write-Log ("thread-control.json detected: ThreadLimitPercent=$threadLimitPercent") 'OK'
        }
    } catch {
        Write-Log "Failed to parse thread-control.json: $_" 'WARN'
    }
}

# If threadLimitPercent is set, patch config.json/config.jason for next miner start
    if ($null -ne $threadLimitPercent) {
    $installPath = if ($cfg.ChknMinerInstallPath) { $cfg.ChknMinerInstallPath } else { 'C:\Program Files\ChKn_miner' }
    $configFiles = @('config.json','config.jason') | ForEach-Object { Join-Path $installPath $_ } | Where-Object { Test-Path $_ }
    foreach ($cfgFile in $configFiles) {
        try {
            $cfgObj = Get-Content $cfgFile -Raw | ConvertFrom-Json
            if ($cfgObj.PSObject.Properties['cpu'] -and $cfgObj.cpu.PSObject.Properties['threads']) {
                $origThreads = $cfgObj.cpu.threads
                $cfgObj.cpu.threads = $threadLimitPercent
                $safeCfgObj = Convert-ToEvidenceSafeValue -Value $cfgObj
                $safeCfgObj | ConvertTo-Json -Depth 8 | Set-Content -Path $cfgFile -Encoding UTF8
                $msg = 'Patched {0}: cpu.threads {1} -> {2} (from thread-control.json)' -f $cfgFile, $origThreads, $threadLimitPercent
                Write-Log $msg 'OK'
            }
        } catch {
            Write-Log "Failed to patch $cfgFile for thread control: $_" 'WARN'
        }
    }
}
$StateRoot = 'C:\ProgramData\LabDeploy\FleetMGR-State'
New-Item -ItemType Directory -Path $StateRoot -Force | Out-Null
$ProofPath = Join-Path $StateRoot ("fleetmgr-proof-{0}-{1}.json" -f $env:COMPUTERNAME,$RunId)
$LatestProofPath = Join-Path $StateRoot 'fleetmgr-proof-latest.json'
$results = New-Object System.Collections.Generic.List[object]
$EvidenceExported = $false
$EvidenceExportFailed = $false
$EvidenceExportFailureReason = ''
$script:FatalTrapHandled = $false
$ScriptLabel = 'FleetMGR-ChknMNR'
$HeartbeatSourceId = "FleetMGR-Heartbeat-$RunId"
$EvidenceHelperPath = Join-Path $ScriptRoot 'FleetMGR-Evidence-Export.ps1'
if(Test-Path -LiteralPath $EvidenceHelperPath){ . $EvidenceHelperPath }

function Get-OneDriveEvidenceRoot {
    $candidates = @(
        (Join-Path $env:USERPROFILE 'OneDrive - Securement'),
        (Join-Path $env:USERPROFILE 'OneDrive'),
        $env:OneDriveCommercial,
        $env:OneDrive
    ) | Where-Object { $_ }

    foreach($path in ($candidates | Select-Object -Unique)){
        if(Test-Path -LiteralPath $path){ return $path }
    }
    return $null
}

function Invoke-PostInstallConditionMonitorRun {
    $conditionMonitor = Join-Path $ScriptRoot 'ChknMiner-Condition-Monitor.ps1'
    if (-not (Test-Path -LiteralPath $conditionMonitor)) {
        $conditionMonitor = Join-Path $RuntimePackageRoot 'ChknMiner-Condition-Monitor.ps1'
    }
    if (Test-Path -LiteralPath $conditionMonitor) {
        Write-Log 'Running ChknMiner-Condition-Monitor once for deployment thermal evidence...' 'INFO'
        & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $conditionMonitor -PackageRoot $ScriptRoot
        $conditionExit = $LASTEXITCODE
        Write-Log ("ChknMiner-Condition-Monitor exit code: {0}" -f $conditionExit) 'INFO'
    } else {
        Write-Log 'ChknMiner-Condition-Monitor.ps1 missing; thermal evidence unavailable.' 'WARN'
    }
}

function Invoke-OneDriveEvidenceExport {
    param(
        [string]$Outcome = 'UNKNOWN',
        [string]$ErrorText = ''
    )

    Stop-HeartbeatSync
    if($EvidenceExported){ return }
    $resolvedOneDriveRoot = Get-OneDriveEvidenceRoot
    if(-not $resolvedOneDriveRoot){
        Write-Log 'OneDriveEvidence=UNAVAILABLE' 'WARN'
        if($OneDriveRequired){
            $script:EvidenceExportFailed = $true
            $script:EvidenceExportFailureReason = 'OneDrive is required but unavailable'
        }
        $script:EvidenceExported = $true
        return
    }
    if(Get-Command Invoke-FleetMgrEvidenceExport -ErrorAction SilentlyContinue){
        try {
            $artifactPaths = @(
                $ProofPath,
                $LatestProofPath,
                'C:\ProgramData\LabDeploy\compliance-inventory.json',
                'C:\ProgramData\LabDeploy\installer-diagnostic.txt',
                'C:\ProgramData\LabDeploy\chknminer-install.log',
                'C:\ProgramData\LabDeploy\chknminer-status.json',
                'C:\ProgramData\LabDeploy\chknminer-condition-state.json'
            )
            $normalizedResults = Get-NormalizedResultObject
            $metadata = [ordered]@{
                proof_path = $ProofPath
                latest_proof_path = $LatestProofPath
                stage_count = @($results).Count
                onedrive_evidence_status = 'AVAILABLE'
            }
            $exportResult = Invoke-FleetMgrEvidenceExport -ScriptLabel $ScriptLabel -RunId $RunId -Outcome $Outcome -ErrorText $ErrorText -OneDriveRoot $resolvedOneDriveRoot -LogPaths @($LogPath,$LegacyLogPath) -ArtifactPaths $artifactPaths -StateRoot $StateRoot -ResultObject $normalizedResults -ExtraMetadata $metadata
            $dest = if ($exportResult -and $exportResult.PSObject -and $exportResult.PSObject.Properties['Destination']) { [string]$exportResult.Destination } else { [string]$exportResult }
            if(-not $dest -or -not (Test-Path -LiteralPath $dest)){
                throw 'Evidence export destination missing after export.'
            }
            $requiredExportFiles = @('compliance-inventory.json')
            $missingExportFiles = @()
            foreach($name in $requiredExportFiles){
                if(-not (Test-Path -LiteralPath (Join-Path $dest $name))){
                    $missingExportFiles += $name
                }
            }
            $proofAtRoot = Test-Path -LiteralPath (Join-Path $dest 'fleetmgr-proof-latest.json')
            $proofAtState = Test-Path -LiteralPath (Join-Path $dest 'FleetMGR-State\fleetmgr-proof-latest.json')
            if((-not $proofAtRoot) -and (-not $proofAtState)){
                $missingExportFiles += 'fleetmgr-proof-latest.json (root or FleetMGR-State)'
            }
            if(@($missingExportFiles).Count -gt 0){
                throw ('Evidence export incomplete. Missing: ' + ($missingExportFiles -join ', '))
            }
            if($dest){ Write-Log "SYNC_TARGET=$dest" 'OK' }
        } catch {
            Write-Log "Evidence export failed: $($_.Exception.Message)" 'ERROR'
            $script:EvidenceExportFailed = $true
            $script:EvidenceExportFailureReason = [string]$_.Exception.Message
        }
    }
    else {
        Write-Log 'Evidence export skipped: helper script missing.' 'ERROR'
        $script:EvidenceExportFailed = $true
        $script:EvidenceExportFailureReason = 'helper script missing'
    }
    $script:EvidenceExported = $true
}

function Invoke-HeartbeatSync {
    $root = Get-OneDriveEvidenceRoot
    if(-not $root){ return }

    $livePath = Join-Path $root ("FleetMGR-Evidence\\LIVE\\{0}\\{1}" -f $env:COMPUTERNAME, $ScriptLabel)
    New-Item -ItemType Directory -Path $livePath -Force | Out-Null

    foreach($artifact in @($LogPath,$LegacyLogPath,$ProofPath,$LatestProofPath,'C:\ProgramData\LabDeploy\installer-diagnostic.txt','C:\ProgramData\LabDeploy\chknminer-install.log','C:\ProgramData\LabDeploy\chknminer-status.json','C:\ProgramData\LabDeploy\chknminer-condition-state.json')){
        if($artifact -and (Test-Path -LiteralPath $artifact)){
            Copy-Item -LiteralPath $artifact -Destination $livePath -Force -ErrorAction SilentlyContinue
        }
    }

    "heartbeat $(Get-Date -Format o)" | Set-Content -LiteralPath (Join-Path $livePath 'heartbeat.txt') -Encoding UTF8
    if(Get-Command Invoke-FleetMgrOneDriveSyncNow -ErrorAction SilentlyContinue){
        Invoke-FleetMgrOneDriveSyncNow -EvidencePath $livePath -OneDriveRoot $root | Out-Null
    }
}

function Start-HeartbeatSync {
    Register-ObjectEvent -InputObject (New-Object System.Timers.Timer -Property @{ Interval = 60000; AutoReset = $true; Enabled = $true }) -EventName Elapsed -SourceIdentifier $HeartbeatSourceId -Action {
        try { Invoke-HeartbeatSync } catch {}
    } | Out-Null
    Invoke-HeartbeatSync
    Write-Log 'Heartbeat sync enabled (60s).' 'INFO'
}

function Stop-HeartbeatSync {
    Unregister-Event -SourceIdentifier $HeartbeatSourceId -ErrorAction SilentlyContinue
    Get-Job -Name $HeartbeatSourceId -ErrorAction SilentlyContinue | Remove-Job -Force -ErrorAction SilentlyContinue
}

trap {
    if ($script:FatalTrapHandled) { exit 1 }
    $script:FatalTrapHandled = $true

    $err = $_
    $trapErrorText = if ($err.Exception) { $err.Exception.Message } else { [string]$err }
    $trapErrorType = if ($err.Exception) { $err.Exception.GetType().FullName } else { 'UnhandledError' }
    $trapLine = $null
    $trapCommand = $null
    try { $trapLine = $err.InvocationInfo.ScriptLineNumber } catch {}
    try { $trapCommand = $err.InvocationInfo.Line } catch {}
    $failureDetail = [ordered]@{
        type = $trapErrorType
        message = $trapErrorText
        line = $trapLine
        command = $trapCommand
        script = $MyInvocation.MyCommand.Path
    }
    try { Write-Log ("Unhandled error trapped: {0} - {1}" -f $trapErrorType, $trapErrorText) 'ERROR' } catch {}
    try { Write-Checkpoint -Stage 'TRAP' -Detail $failureDetail } catch {}
    try { Add-Result 'UNHANDLED-TRAP' $false $failureDetail } catch {}
    try { Write-FinalStatusRecord -Outcome 'ERROR' -ExitCode 1 -ErrorText ("{0}: {1}" -f $trapErrorType, $trapErrorText) } catch {}
    try { Invoke-OneDriveEvidenceExport -Outcome 'ERROR' -ErrorText ("{0}: {1}" -f $trapErrorType, $trapErrorText) } catch {}
    exit 1
}
function Get-ChknCpuTemperatureEvidence {
    $result = @{ Status = 'Unavailable'; Value = $null; Raw = $null }
    try {
        $wmi = Get-WmiObject MSAcpi_ThermalZoneTemperature -Namespace "root\wmi" -ErrorAction Stop
        if ($wmi -and $wmi.CurrentTemperature) {
            $tempC = [math]::Round(($wmi.CurrentTemperature - 2732) / 10, 1)
            $result.Status = 'OK'
            $result.Value = $tempC
            $result.Raw = $wmi.CurrentTemperature
        } else {
            $result.Status = 'Unavailable'
        }
    } catch {
        $result.Status = 'Unavailable'
        $result.Raw = if ($_.Exception -and $_.Exception.Message) { [string]$_.Exception.Message } else { 'CPU temperature unavailable' }
    }
    return $result
}

function Get-ChknThreadLimitDecision {
    param(
        [object]$ThermalPolicy,
        [object]$CpuTempEvidence,
        [bool]$ThermalEnabled = $false
    )
    $default = @{ ThreadLimitPercent = 100; ApplyStatus = 'PolicyBypass'; Reason = 'Thermal control not enabled or unavailable' }
    if (-not $ThermalEnabled -or -not $ThermalPolicy) { return $default }
    if ($CpuTempEvidence.Status -ne 'OK' -or $null -eq $CpuTempEvidence.Value) {
        return @{ ThreadLimitPercent = 100; ApplyStatus = 'Unavailable'; Reason = 'CPU temp unavailable' }
    }
    $maxSafe = [int]$ThermalPolicy.MaxSafeTempC
    $minPct = [int]$ThermalPolicy.MinThreadPercent
    $maxPct = [int]$ThermalPolicy.MaxThreadPercent
    $ramp = [int]$ThermalPolicy.TempRampC
    $step = [int]$ThermalPolicy.ThreadStepPercent
    $temp = [double]$CpuTempEvidence.Value
    if ($temp -le ($maxSafe - $ramp)) {
        $reason = 'Temp ' + $temp + ' <= ' + ($maxSafe-$ramp) + ': max threads'
        return @{ ThreadLimitPercent = $maxPct; ApplyStatus = 'OK'; Reason = $reason }
    } elseif ($temp -ge $maxSafe) {
        $reason = 'Temp ' + $temp + ' >= ' + $maxSafe + ': min threads'
        return @{ ThreadLimitPercent = $minPct; ApplyStatus = 'OK'; Reason = $reason }
    } else {
        $delta = $temp - ($maxSafe - $ramp)
        $frac = $delta / $ramp
        $pct = [math]::Round($maxPct - ($maxPct-$minPct)*$frac)
        $pct = [math]::Max([math]::Min($pct, $maxPct), $minPct)
        $pct = [math]::Round($pct/$step)*$step
        $reason = 'Temp ' + $temp + ' in ramp: ' + $pct + '% threads'
        return @{ ThreadLimitPercent = $pct; ApplyStatus = 'OK'; Reason = $reason }
    }
}

function Write-Proof {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    $stageSnapshot = if($results){ @($results.ToArray()) } else { @() }
    $thermalEnabled = $false
    $thermalRequired = $false
    $thermalPolicy = $null
    if($cfg.PSObject.Properties['ThermalThreadControlEnabled']){ $thermalEnabled = [bool]$cfg.ThermalThreadControlEnabled }
    if($cfg.PSObject.Properties['ThermalMonitorRequired']){ $thermalRequired = [bool]$cfg.ThermalMonitorRequired }
    if($cfg.PSObject.Properties['ThermalPolicy']){ $thermalPolicy = $cfg.ThermalPolicy }
    $cpuTempEvidence = Get-ChknCpuTemperatureEvidence
    $threadDecision = Get-ChknThreadLimitDecision -ThermalPolicy $thermalPolicy -CpuTempEvidence $cpuTempEvidence -ThermalEnabled:$thermalEnabled
    $proof = [ordered]@{
        RunId = $RunId
        ComputerName = $env:COMPUTERNAME
        GeneratedAt = (Get-Date).ToString('o')
        ScriptRoot = $ScriptRoot
        WorkingDirectory = (Get-Location).Path
        RuntimePackageRoot = $RuntimePackageRoot
        IsAdmin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
        CurrentUser = $identity.Name
        ExecutionPolicy = (Get-ExecutionPolicy)
        CanonicalServiceName = $CanonicalServiceName
        CanonicalConfigFile = $CanonicalConfigFileName
        Stages = (Get-NormalizedResultObject)
        # Thermal/thread evidence
        ThermalThreadControlEnabled = $thermalEnabled
        ThermalMonitorRequired = $thermalRequired
        ThermalPolicy = $thermalPolicy
        CpuTempStatus = $cpuTempEvidence.Status
        CpuTempC      = $cpuTempEvidence.Value
        CpuTempRaw    = $cpuTempEvidence.Raw
        ThreadLimitPercent = $threadDecision.ThreadLimitPercent
        ThreadApplyStatus  = $threadDecision.ApplyStatus
        ThreadDecisionReason = $threadDecision.Reason
    }
    $safeProof = Convert-ToEvidenceSafeValue -Value $proof
    $json = $safeProof | ConvertTo-Json -Depth 8
    $json | Set-Content -LiteralPath $ProofPath -Encoding UTF8
    $json | Set-Content -LiteralPath $LatestProofPath -Encoding UTF8
    # Add as a result step for audit
    Add-Result 'THERMAL-THREAD-EVIDENCE' $true ([ordered]@{
        ThermalThreadControlEnabled = $thermalEnabled
        ThermalMonitorRequired = $thermalRequired
        ThermalPolicy = $thermalPolicy
        CpuTempStatus = $cpuTempEvidence.Status
        CpuTempC      = $cpuTempEvidence.Value
        CpuTempRaw    = $cpuTempEvidence.Raw
        ThreadLimitPercent = $threadDecision.ThreadLimitPercent
        ThreadApplyStatus  = $threadDecision.ApplyStatus
        ThreadDecisionReason = $threadDecision.Reason
    })
}
function Add-Result {
    param([string]$Step,[bool]$Success,[object]$Detail='')
    $results.Add([pscustomobject]@{
        Step = $Step
        Success = $Success
        Detail = Convert-ToEvidenceSafeValue -Value $Detail
        Timestamp = (Get-Date).ToString('o')
    })
    Write-Proof
}
Start-HeartbeatSync
function Resolve-MinerServiceName {
    $candidates = @()
    if($cfg.PSObject.Properties['ChknMinerServiceName'] -and $cfg.ChknMinerServiceName){ $candidates += [string]$cfg.ChknMinerServiceName }
    $candidates += @('ChKn_miner','Chkn_miner','ChknMiner')
    foreach($name in ($candidates | Where-Object { $_ } | Select-Object -Unique)){
        if(Get-Service -Name $name -ErrorAction SilentlyContinue){ return $name }
    }
    if($cfg.PSObject.Properties['ChknMinerServiceName'] -and $cfg.ChknMinerServiceName){ return [string]$cfg.ChknMinerServiceName }
    return 'ChKn_miner'
}
function Get-CanonicalConfigPath {
    param([string]$InstallPath)
    $canonicalPath = Join-Path $InstallPath $CanonicalConfigFileName
    if(Test-Path -LiteralPath $canonicalPath){ return $canonicalPath }
    $fallback = if($CanonicalConfigFileName -ieq 'config.json'){ 'config.jason' } else { 'config.json' }
    $fallbackPath = Join-Path $InstallPath $fallback
    if(Test-Path -LiteralPath $fallbackPath){ return $fallbackPath }
    return $canonicalPath
}
function Test-ZeroTouchRuntime {
    $svc = Get-Service -ErrorAction SilentlyContinue | Where-Object {
        $_.Name -match '^ZT|Zero|Touch' -or $_.DisplayName -match 'Zero.?Touch|ZT'
    } | Select-Object -First 1
    return [bool]$svc
}
function Test-TaskPresent([string]$Name) {
    return [bool](Get-ScheduledTask -TaskName $Name -ErrorAction SilentlyContinue)
}
function Test-TaskHealthy {
    param(
        [Parameter(Mandatory=$true)][string]$TaskName,
        [Parameter(Mandatory=$true)][string]$ExpectedScriptPath
    )
    $task = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
    if (-not $task) { return $false }
    $action = $task.Actions | Select-Object -First 1
    if (-not $action) { return $false }
    $arguments = [string]$action.Arguments
    if ($arguments -notmatch [regex]::Escape($ExpectedScriptPath)) { return $false }
    return $true
}
function Invoke-EnsureManagerTask {
    param(
        [Parameter(Mandatory=$true)][string]$TaskName,
        [Parameter(Mandatory=$true)][string]$ScriptPath,
        [string]$ScriptArguments = '',
        [int]$Minutes = 5,
        [switch]$AtStartup
    )
    $healthy = Test-TaskHealthy -TaskName $TaskName -ExpectedScriptPath $ScriptPath
    if ($healthy) {
        $detail = Get-TaskProofObject -Name $TaskName -Attempted $false -Succeeded $true
        $detail['BotTaskAction'] = 'NO_ACTION'
        return [pscustomobject]@{
            Success = $true
            Detail = $detail
        }
    }

    [void](Register-FleetScheduledTask -TaskName $TaskName -ScriptPath $ScriptPath -ScriptArguments $ScriptArguments -Minutes $Minutes -AtStartup:$AtStartup)
    $detail = Get-TaskProofObject -Name $TaskName -Attempted $true -Succeeded $true
    $detail['BotTaskAction'] = 'REGISTER_OR_REPAIR'
    return [pscustomobject]@{
        Success = $true
        Detail = $detail
    }
}
function Get-TaskProofObject([string]$Name,[bool]$Attempted = $false,[bool]$Succeeded = $false) {
    $task = Get-ScheduledTask -TaskName $Name -ErrorAction SilentlyContinue
    $found = [bool]$task
    $actionDetails = @()
    $triggerDetails = @()
    $principalUser = ''
    $runLevel = ''
    $taskPath = ''
    $state = 'Missing'
    $lastTaskResult = $null
    $nextRun = $null
    if($task){
        $taskPath = $task.TaskPath
        $state = [string]$task.State
        $principalUser = [string]$task.Principal.UserId
        $runLevel = [string]$task.Principal.RunLevel
        $actionDetails = @($task.Actions | ForEach-Object {
            [ordered]@{
                Execute = $_.Execute
                Arguments = $_.Arguments
                WorkingDirectory = $_.WorkingDirectory
            }
        })
        $triggerDetails = @($task.Triggers | ForEach-Object {
            [ordered]@{
                Type = $_.CimClass.CimClassName
                StartBoundary = $_.StartBoundary
                RepetitionInterval = $_.Repetition.Interval
            }
        })
        $info = Get-ScheduledTaskInfo -TaskName $Name -TaskPath $task.TaskPath -ErrorAction SilentlyContinue
        if($info){
            $lastTaskResult = $info.LastTaskResult
            $nextRun = $info.NextRunTime
        }
    }
    return [ordered]@{
        task_name = $Name
        task_registration_attempted = $Attempted
        task_registration_succeeded = $Succeeded
        found = $found
        task_path = $taskPath
        state = $state
        principal_user = $principalUser
        run_level = $runLevel
        actions = $actionDetails
        triggers = $triggerDetails
        last_task_result = $lastTaskResult
        next_run = $nextRun
    }
}
function Get-TaskProofDetail([string]$Name) {
    $obj = Get-TaskProofObject -Name $Name
    $safeObj = Convert-ToEvidenceSafeValue -Value $obj
    return ($safeObj | ConvertTo-Json -Compress -Depth 6)
}
function Register-FleetScheduledTask {
    param(
        [Parameter(Mandatory=$true)][string]$TaskName,
        [Parameter(Mandatory=$true)][string]$ScriptPath,
        [string]$ScriptArguments = '',
        [int]$Minutes = 5,
        [switch]$AtStartup
    )
    Write-Log "Task Registration START: $TaskName" 'DEBUG'
    Write-Log "  Script: $ScriptPath" 'DEBUG'
    Write-Log "  Args: $ScriptArguments" 'DEBUG'
    Write-Log "  Interval: $Minutes min" 'DEBUG'
    
    if(-not (Test-Path -LiteralPath $ScriptPath)){
        $err = "Task script missing: $ScriptPath"
        Write-Log $err 'ERROR'
        throw $err
    }
    
    Write-Log "  Removing any existing task: $TaskName" 'DEBUG'
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue | Out-Null
    
    Write-Log "  Building task action" 'DEBUG'
    $taskArgs = ('-NoProfile -ExecutionPolicy Bypass -File "{0}" {1}' -f $ScriptPath,$ScriptArguments).Trim()
    Write-Log "  Full command: powershell.exe $taskArgs" 'DEBUG'
    $action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $taskArgs -WorkingDirectory $RuntimePackageRoot
    Write-Log "  WorkingDirectory: $RuntimePackageRoot" 'DEBUG'
    
    Write-Log "  Building task triggers" 'DEBUG'
    $triggers = @()
    if($AtStartup){ 
        Write-Log "    Adding AtStartup trigger" 'DEBUG'
        $triggers += New-ScheduledTaskTrigger -AtStartup 
    }
    $nextRun = (Get-Date).AddMinutes(1)
    Write-Log "    Adding repetition trigger (first run: $nextRun, repeat every $Minutes min)" 'DEBUG'
    $triggers += New-ScheduledTaskTrigger -Once -At $nextRun -RepetitionInterval ([timespan]::FromMinutes($Minutes))
    
    Write-Log "  Building principal (SYSTEM/Highest)" 'DEBUG'
    $principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -RunLevel Highest
    Write-Log "  Principal: UserId=SYSTEM RunLevel=Highest" 'DEBUG'
    
    Write-Log "  Building settings" 'DEBUG'
    $settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew
    
    Write-Log "  Calling Register-ScheduledTask" 'DEBUG'
    try {
        Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $triggers -Principal $principal -Settings $settings -Force -ErrorAction Stop | Out-Null
        Write-Log "  Register-ScheduledTask succeeded" 'DEBUG'
    } catch {
        $err = "Register-ScheduledTask failed: $_"
        Write-Log $err 'ERROR'
        throw $err
    }
    
    Write-Log "  Verifying task exists" 'DEBUG'
    $registered = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
    if(-not $registered){
        $err = "Task registration returned success but task is missing: $TaskName"
        Write-Log $err 'ERROR'
        throw $err
    }
    Write-Log "  Task verified present" 'DEBUG'
    
    Write-Log "  Attempting first start" 'DEBUG'
    try {
        Start-ScheduledTask -TaskName $TaskName -ErrorAction Stop
        Write-Log "  Start-ScheduledTask succeeded" 'DEBUG'
        Start-Sleep -Seconds 2
    } catch {
        Write-Log "  Start-ScheduledTask failed (non-critical): $_" 'WARN'
    }
    
    $detail = Get-TaskProofDetail $TaskName
    Write-Log "  Task Registration COMPLETE" 'DEBUG'
    Write-Log "  Proof detail: $detail" 'DEBUG'
    return $detail
}
function Get-JsonArtifactDetail([string]$Path) {
    if(-not (Test-Path -LiteralPath $Path)){ return "Missing $Path" }
    try {
        $json = Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json
        $parts = @()
        foreach($name in @('ServiceName','ServiceStatus','CanonicalConfig','ConfigJasonPresent','ConfigJsonPresent','ControlPanelPresent','desiredState','actionTaken','shouldMine','serviceStatus')){
            if($json.PSObject.Properties[$name]){ $parts += "$name=$($json.$name)" }
        }
        if($parts.Count -eq 0){ return "Present $Path" }
        return ($parts -join '; ')
    } catch {
        return "Present but unreadable JSON: $_"
    }
}
function Invoke-PostInstallTruth {
    Step-Banner 'Runtime truth checks'
    if(-not $SkipZT){
        $ztOk = Test-ZeroTouchRuntime
        if($ztOk){
            Add-Result 'POST-ZT-Runtime' $true 'ZeroTouch service/app evidence after install'
        } else {
            $ztDetail = if($ZeroTouchRequired){ 'ZeroTouch runtime evidence missing and required by configuration.' } else { 'NON_BLOCKING_WITH_REASON: ZeroTouch runtime evidence missing but ZeroTouchRequired=false.' }
            Add-Result 'POST-ZT-Runtime' (-not $ZeroTouchRequired) $ztDetail
        }
    }
    # CyberCrucible post-check disabled — CC assumed present, step bypassed
    Add-Result 'POST-CyberCrucible-Runtime' $true 'bypassed'
    foreach($payload in @('05-ChknMiner-Install.ps1','ChknMiner-Updater-Agent.ps1','ChknMiner-BotRules.ps1','ChknMiner-Condition-Monitor.ps1','DEPLOY-CONFIG.json','ChKn_miner_installer_x64.exe')){
        $payloadPath = Join-Path $RuntimePackageRoot $payload
        Add-Result "POST-Payload-$payload" (Test-Path -LiteralPath $payloadPath) $payloadPath
    }

    $installPath = if($cfg.PSObject.Properties['ChknMinerInstallPath'] -and $cfg.ChknMinerInstallPath){ [string]$cfg.ChknMinerInstallPath } else { 'C:\Program Files\ChKn_miner' }
    $serviceName = Resolve-MinerServiceName
    $svc = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
    Add-Result 'POST-ChKn-Service' ([bool]$svc) ([ordered]@{ service_name = $serviceName; status = [string]$svc.Status })
    $controlPanelPath = Join-Path $installPath 'ChKn_miner_control.exe'
    $controlPanelExists = Test-Path -LiteralPath $controlPanelPath
    $controlPanelRequired = $false
    if($cfg.PSObject.Properties['ControlPanelRequired'] -and $null -ne $cfg.ControlPanelRequired){
        $controlPanelRequired = [bool]$cfg.ControlPanelRequired
    }
    $controlPanelBlocking = $controlPanelRequired
    $controlPanelReason = 'Control panel executable present.'
    if(-not $controlPanelExists){
        if($svc -and -not $controlPanelRequired){
            $controlPanelBlocking = $false
            $controlPanelReason = 'Control panel missing but miner service/runtime exists; treated as non-blocking for deployment.'
        } else {
            $controlPanelBlocking = $true
            $controlPanelReason = if($controlPanelRequired){ 'Control panel is required by DEPLOY-CONFIG.json and is missing.' } else { 'Control panel missing and miner service missing; blocking.' }
        }
    }
    Add-Result 'POST-ChKn-ControlPanel' ($controlPanelExists -or -not $controlPanelBlocking) ([ordered]@{
        path = $controlPanelPath
        exists = $controlPanelExists
        required = $controlPanelRequired
        blocking = $controlPanelBlocking
        reason = $controlPanelReason
    })
    Add-Result 'POST-ChKn-ConfigJason' (Test-Path -LiteralPath (Join-Path $installPath 'config.jason')) (Join-Path $installPath 'config.jason')
    Add-Result 'POST-ChKn-ConfigJson' (Test-Path -LiteralPath (Join-Path $installPath 'config.json')) (Join-Path $installPath 'config.json')
    $canonicalConfigPath = Get-CanonicalConfigPath -InstallPath $installPath
    Add-Result 'POST-ChKn-CanonicalConfig' (Test-Path -LiteralPath $canonicalConfigPath) ([ordered]@{ canonical_config = $CanonicalConfigFileName; selected_path = $canonicalConfigPath })

    if(-not $SkipAgent){
        $updaterTask = Get-TaskProofObject -Name 'ChknMinerUpdaterAgent' -Attempted $true -Succeeded (Test-TaskPresent 'ChknMinerUpdaterAgent')
        $botRulesTask = Get-TaskProofObject -Name 'ChknMinerBotRules' -Attempted $true -Succeeded (Test-TaskPresent 'ChknMinerBotRules')
        Add-Result 'POST-Task-Updater' $updaterTask.found $updaterTask
        Add-Result 'POST-Task-BotRules' $botRulesTask.found $botRulesTask
    }
    if(-not $SkipConditionMonitor){
        $conditionTask = Get-TaskProofObject -Name 'ChknMinerConditionMonitor' -Attempted $true -Succeeded (Test-TaskPresent 'ChknMinerConditionMonitor')
        Add-Result 'POST-Task-ConditionMonitor' $conditionTask.found $conditionTask
    }

    $expectedTaskNames = @()
    if(-not $SkipAgent){
        $expectedTaskNames += 'ChknMinerUpdaterAgent'
        $expectedTaskNames += 'ChknMinerBotRules'
    }
    if(-not $SkipConditionMonitor){
        $expectedTaskNames += 'ChknMinerConditionMonitor'
    }
    $foundTasks = @($expectedTaskNames | Where-Object { Test-TaskPresent $_ })
    Add-Result 'POST-Task-Registration-Summary' ($foundTasks.Count -eq $expectedTaskNames.Count) ([ordered]@{
        task_registration_attempted = $true
        task_registration_succeeded = ($foundTasks.Count -eq $expectedTaskNames.Count)
        expected_task_names = $expectedTaskNames
        found_task_names = $foundTasks
    })

    $botRules = Join-Path $RuntimePackageRoot 'ChknMiner-BotRules.ps1'
    if(Test-Path -LiteralPath $botRules){
        try { & $botRules -Rule Status | Out-Null; Add-Result 'POST-BotRules-Status-Run' $true 'Status artifact refresh invoked' }
        catch { Add-Result 'POST-BotRules-Status-Run' $false "$_" }
    } else { Add-Result 'POST-BotRules-Status-Run' $false "Missing $botRules" }

    $condition = Join-Path $RuntimePackageRoot 'ChknMiner-Condition-Monitor.ps1'
    if(Test-Path -LiteralPath $condition){
        try { & $condition | Out-Null; Add-Result 'POST-ConditionMonitor-Run' $true 'Condition artifact refresh invoked' }
        catch { Add-Result 'POST-ConditionMonitor-Run' $false "$_" }
    } else { Add-Result 'POST-ConditionMonitor-Run' $false "Missing $condition" }

    $statusArtifact = 'C:\ProgramData\LabDeploy\chknminer-status.json'
    $conditionArtifact = 'C:\ProgramData\LabDeploy\chknminer-condition-state.json'
    Add-Result 'POST-Status-Artifact' (Test-Path -LiteralPath $statusArtifact) (Get-JsonArtifactDetail $statusArtifact)
    Add-Result 'POST-Condition-Artifact' (Test-Path -LiteralPath $conditionArtifact) (Get-JsonArtifactDetail $conditionArtifact)
    Write-Log "Runtime proof written: $ProofPath" 'OK'
}
function Test-CyberCrucibleInstalled {
    $evidence = [ordered]@{ Installed = $false; EvidenceType = 'none'; EvidenceValue = '' }

    # Check process name only — no .Path access (blocked by CC anti-exploit layer)
    $proc = Get-Process -ErrorAction SilentlyContinue | Where-Object {
        $_.ProcessName -match 'rpp|Cyber|Crucible'
    } | Select-Object -First 1
    if($proc){
        $evidence.Installed = $true
        $evidence.EvidenceType = 'process'
        $evidence.EvidenceValue = $proc.ProcessName
        return $evidence
    }

    # Use Get-Service (SCM API — not blocked by CC unlike CimInstance/WMI)
    $svc = Get-Service -ErrorAction SilentlyContinue | Where-Object {
        $_.Name -match 'rpp|Cyber.?Crucible|Crucible' -or
        $_.DisplayName -match 'rpp|Cyber.?Crucible|Crucible'
    } | Select-Object -First 1
    if($svc){
        $evidence.Installed = $true
        $evidence.EvidenceType = 'service'
        $evidence.EvidenceValue = $svc.Name
        return $evidence
    }

    # Directory check — fixed paths plus wildcard scan under Program Files
    $paths = @(
        'C:\Program Files\CyberCrucible',
        'C:\Program Files (x86)\CyberCrucible',
        'C:\ProgramData\CyberCrucible'
    )
    foreach($path in $paths){
        if(Test-Path -LiteralPath $path){
            $evidence.Installed = $true
            $evidence.EvidenceType = 'directory'
            $evidence.EvidenceValue = $path
            return $evidence
        }
    }
    $wildDir = Get-ChildItem 'C:\Program Files','C:\Program Files (x86)' -Directory -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -match 'rpp|Cyber|Crucible' } | Select-Object -First 1
    if($wildDir){
        $evidence.Installed = $true
        $evidence.EvidenceType = 'directory'
        $evidence.EvidenceValue = $wildDir.FullName
        return $evidence
    }

    $registryRoots = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )
    foreach($root in $registryRoots){
        $hit = Get-ItemProperty -Path $root -ErrorAction SilentlyContinue | Where-Object {
            $_.DisplayName -match 'Cyber.?Crucible|Crucible|RPP' -or
            $_.Publisher -match 'Cyber.?Crucible|RPP' -or
            $_.InstallLocation -match 'CyberCrucible|rpp' -or
            $_.UninstallString -match 'CyberCrucible|rpp'
        } | Select-Object -First 1
        if($hit){
            $evidence.Installed = $true
            $evidence.EvidenceType = 'registry-uninstall'
            $evidence.EvidenceValue = [string]$hit.DisplayName
            return $evidence
        }
    }
    return $evidence
}
Add-Result 'INSTALLER-ENTRY' $true "FleetMGR-ChknMNR.ps1 started from $ScriptRoot"
Write-Checkpoint -Stage 'INSTALLER_ENTRY'
function Resolve-SiteToken {
    param([string]$OperatorProvidedPath)

    if(-not [string]::IsNullOrWhiteSpace($env:SITE_TOKEN)){
        return [pscustomobject]@{ Token = $env:SITE_TOKEN.Trim(); SourceType = 'env' }
    }

    $defaultPath = 'C:\ProgramData\LabDeploy\Secrets\site-token.txt'
    if(Test-Path -LiteralPath $defaultPath){
        $fromDefault = (Get-Content -LiteralPath $defaultPath -Raw).Trim()
        if(-not [string]::IsNullOrWhiteSpace($fromDefault)){
            return [pscustomobject]@{ Token = $fromDefault; SourceType = 'file' }
        }
    }

    if($OperatorProvidedPath -and (Test-Path -LiteralPath $OperatorProvidedPath)){
        $fromOperator = (Get-Content -LiteralPath $OperatorProvidedPath -Raw).Trim()
        if(-not [string]::IsNullOrWhiteSpace($fromOperator)){
            return [pscustomobject]@{ Token = $fromOperator; SourceType = 'operator_path' }
        }
    }

    return [pscustomobject]@{ Token = $null; SourceType = 'missing' }
}
if(-not $SkipZT){
    Step-Banner 'Step 1: Uninstall existing ZeroTouch'
    $ztProduct = Get-WmiObject -Class Win32_Product -ErrorAction SilentlyContinue | Where-Object { $_.Name -like '*ZeroTouch*' -or $_.Name -like '*Zero Touch*' -or $_.Name -like '*ZTPkg*' } | Select-Object -First 1
    if($ztProduct){ try{ $u=Start-Process 'msiexec.exe' -ArgumentList "/x `"$($ztProduct.IdentifyingNumber)`" /qn /norestart" -Wait -PassThru; if($u.ExitCode -eq 0 -or $u.ExitCode -eq 1605){Write-Log 'ZeroTouch uninstalled.' 'OK'; Add-Result 'ZT-Uninstall' $true}else{Write-Log "ZeroTouch uninstall exit code: $($u.ExitCode)" 'WARN'; Add-Result 'ZT-Uninstall' $false "Exit $($u.ExitCode)"} } catch { Write-Log "ZeroTouch uninstall error: $_" 'ERROR'; Add-Result 'ZT-Uninstall' $false "$_" } }
    else { Write-Log 'No existing ZeroTouch installation found; skipping uninstall.' 'OK'; Add-Result 'ZT-Uninstall' $true 'Not installed' }
    Step-Banner 'Step 2: Install ZeroTouch using portal command only'
    try{ $z=Invoke-ZeroTouchPortalCommand -MsiPath $ZTPkgPath -SiteTokenPath $SiteTokenOverridePath; if($z -eq 0 -or $z -eq 3010){Write-Log "ZeroTouch installed. ExitCode=$z" 'OK'; Add-Result 'ZT-Install' $true ([ordered]@{ exit_code = $z; msi_path = $ZTPkgPath })}else{Write-Log "ZeroTouch install exit code: $z" 'ERROR'; Add-Result 'ZT-Install' $false ([ordered]@{ exit_code = $z; msi_path = $ZTPkgPath })} } catch { Write-Log "ZeroTouch install error: $_" 'ERROR'; Add-Result 'ZT-Install' $false ([ordered]@{ error = [string]$_; msi_path = $ZTPkgPath }) }
}
if(-not $SkipRemote){
    Step-Banner 'Step 4: Remote VS Code Prep'
    $remoteScript=Join-Path $ScriptRoot '03-Setup-Remote-VSCode-SurfacePro9.ps1'
    if(Test-Path -LiteralPath $remoteScript){
        try{
            & $remoteScript
            Add-Result 'Remote-VSCode' $true 'completed'
            Write-Log 'Remote VS Code prep completed.' 'OK'
        } catch {
            $detail = if($RemoteVSCodeRequired){ [string]$_ } else { "NON_BLOCKING_WITH_REASON: $($_.Exception.Message)" }
            Add-Result 'Remote-VSCode' (-not $RemoteVSCodeRequired) $detail
            Write-Log "Remote VS Code prep error: $_" 'WARN'
        }
    } else {
        $detail = if($RemoteVSCodeRequired){ "Script missing: $remoteScript" } else { "NON_BLOCKING_WITH_REASON: Script missing: $remoteScript" }
        Add-Result 'Remote-VSCode' (-not $RemoteVSCodeRequired) $detail
        Write-Log "Remote prep script missing: $remoteScript" 'WARN'
    }
}
if(-not $SkipMiner){
    Step-Banner 'Step 5: ChKn Miner repair/install'
    Write-Log 'Step 5 trace: enter' 'DEBUG'
    $minerScript=Join-Path $RuntimePackageRoot '05-ChknMiner-Install.ps1'
    $minerExe=Join-Path $RuntimePackageRoot 'ChKn_miner_installer_x64.exe'
    Write-Log "Step 5 trace: minerScript=$minerScript" 'DEBUG'
    Write-Log "Step 5 trace: minerExe=$minerExe" 'DEBUG'
    # HARD PREFLIGHT: both files must be present in staged runtime before executing
    $preflightMissing = @($minerScript,$minerExe) | Where-Object { -not (Test-Path -LiteralPath $_) }
    $preflightMissingCount = @($preflightMissing).Count
    Write-Log ("Step 5 trace: preflightMissingCount={0}" -f $preflightMissingCount) 'DEBUG'
    if($preflightMissingCount -gt 0){
        $preflightErr = 'PREFLIGHT FAIL — Step 5 cannot run. Missing staged payload files: ' + ($preflightMissing -join ', ') + '. Re-run from the full package source (USB or READY-x64 folder that contains 05-ChknMiner-Install.ps1 and ChKn_miner_installer_x64.exe).'
        Write-Log $preflightErr 'ERROR'
        Add-Result 'ChknMiner-Install' $false ([ordered]@{ error = $preflightErr; missing_files = @($preflightMissing); source_path = $ChknMinerSource })
        throw $preflightErr
    }
    Write-Log 'Step 5 trace: before try block' 'DEBUG'
    try{
        Write-Log 'Step 5 trace: try block start' 'DEBUG'
        if(-not (Test-Path -LiteralPath $ChknMinerSource)){
            $localCandidates = @(
                (Join-Path $ScriptRoot 'secminer.zip'),
                (Join-Path $ScriptRoot 'ChknMiner-1.4.3.zip'),
                (Join-Path $RuntimePackageRoot 'secminer.zip'),
                (Join-Path $RuntimePackageRoot 'ChknMiner-1.4.3.zip'),
                (Join-Path $RuntimePackageRoot 'ChKn_miner_installer_x64.exe')
            )
            $resolvedLocal = $localCandidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
            if($resolvedLocal){
                $ChknMinerSource = $resolvedLocal
                Write-Log "Step 5 trace: source was non-local/missing; using local payload $ChknMinerSource" 'WARN'
            } else {
                throw "WINDOWS_BLOCKED_MISSING_LOCAL_PAYLOAD: no local ChKn miner payload found in package roots."
            }
        }
        # Run miner install in an isolated PowerShell process so child script exits
        # cannot terminate this parent run as ScriptHalted.
        $minerArgs = @('-NoProfile','-ExecutionPolicy','Bypass','-File',$minerScript,'-SourcePath',$ChknMinerSource)
        Write-Log ("Step 5 trace: minerArgsCount={0}" -f @($minerArgs).Count) 'DEBUG'
        Write-Log 'Step 5 trace: local payload only mode enforced' 'DEBUG'
        Write-Log ("Launching Step 5 installer: powershell.exe {0}" -f ($minerArgs -join ' ')) 'INFO'
        $minerProc = Start-Process -FilePath 'powershell.exe' -ArgumentList $minerArgs -Wait -PassThru -NoNewWindow
        Write-Log ("Step 5 trace: minerProcExitCode={0}" -f $minerProc.ExitCode) 'DEBUG'
        if($minerProc.ExitCode -eq 0){
            $minerStatusPath = 'C:\ProgramData\LabDeploy\chknminer-status.json'
            $minerStatus = $null
            if(Test-Path -LiteralPath $minerStatusPath){
                try { $minerStatus = Get-Content -LiteralPath $minerStatusPath -Raw | ConvertFrom-Json } catch {}
            }
            Add-Result 'ChknMiner-Install' $true ([ordered]@{
                source_path = $ChknMinerSource
                onedrive_fallback_used = $false
                exit_code = 0
                ChKnMinerAction = if($minerStatus){ [string]$minerStatus.ChKnMinerAction } else { '' }
                ChKnMinerInstallStatus = if($minerStatus){ [string]$minerStatus.ChKnMinerInstallStatus } else { '' }
                DefenderQuarantineStatus = if($minerStatus){ [string]$minerStatus.DefenderQuarantineStatus } else { '' }
            })
            Write-Log 'ChKn miner install/repair completed.' 'OK'
        } else {
            $err = "ChKn miner installer exited non-zero (ExitCode=$($minerProc.ExitCode))."
            Write-Log $err 'ERROR'
            Add-Result 'ChknMiner-Install' $false ([ordered]@{
                error = $err
                source_path = $ChknMinerSource
                onedrive_fallback_used = $false
                exit_code = $minerProc.ExitCode
            })
        }
    } catch {
        Write-Log "ChKn miner install error: $_" 'ERROR'
        Add-Result 'ChknMiner-Install' $false ([ordered]@{
            error = [string]$_
            source_path = $ChknMinerSource
            onedrive_fallback_used = $false
        })
    }
}
if(-not $SkipAgent){
    Step-Banner 'Step 6: Register ChKn bot tasks'
    Write-Log "Checking if agent scripts exist in $RuntimePackageRoot" 'DEBUG'
    $agent = Join-Path $RuntimePackageRoot 'ChknMiner-Updater-Agent.ps1'
    $rules = Join-Path $RuntimePackageRoot 'ChknMiner-BotRules.ps1'
    Write-Log "  Agent script: $(if(Test-Path $agent){'EXISTS'}else{'MISSING'}) $agent" 'DEBUG'
    Write-Log "  Rules script: $(if(Test-Path $rules){'EXISTS'}else{'MISSING'}) $rules" 'DEBUG'
    
    try{
        Write-Log "Registering Updater Agent task" 'INFO'
        $ensure = Invoke-EnsureManagerTask -TaskName 'ChknMinerUpdaterAgent' -ScriptPath $agent -Minutes 30 -AtStartup
        $detail = $ensure.Detail
        Add-Result 'Updater-Agent' $true $detail
        Add-Result 'Step6-UpdaterAgent' $true ([ordered]@{
            TaskName = 'ChknMinerUpdaterAgent'
            TaskPresent = $true
            TaskRegistered = $true
            TaskStartAttempted = $true
            TaskStartResult = 'SUCCESS'
            EvidencePath = $LogPath
            Error = ''
        })
        Write-Log "Updater task ensured. action=$($detail.BotTaskAction)" 'OK'
    } catch {
        Write-Log "Updater task error: $_" 'ERROR'
        $detail = Get-TaskProofObject -Name 'ChknMinerUpdaterAgent' -Attempted $true -Succeeded $false
        $detail['error'] = [string]$_
        Add-Result 'Updater-Agent' $false $detail
        Add-Result 'Step6-UpdaterAgent' $false ([ordered]@{
            TaskName = 'ChknMinerUpdaterAgent'
            TaskPresent = [bool](Test-Path -LiteralPath $agent)
            TaskRegistered = $false
            TaskStartAttempted = $true
            TaskStartResult = 'FAIL'
            EvidencePath = $LogPath
            Error = [string]$_
        })
        throw
    }

    try{
        Write-Log "Registering BotRules task" 'INFO'
        $ensure = Invoke-EnsureManagerTask -TaskName 'ChknMinerBotRules' -ScriptPath $rules -ScriptArguments '-Rule Status' -Minutes 5
        $detail = $ensure.Detail
        Add-Result 'BotRules-Task' $true $detail
        Add-Result 'Step7-BotRules' $true ([ordered]@{
            TaskName = 'ChknMinerBotRules'
            TaskPresent = $true
            TaskRegistered = $true
            TaskStartAttempted = $true
            TaskStartResult = 'SUCCESS'
            EvidencePath = $LogPath
            Error = ''
        })
        Write-Log "BotRules task ensured. action=$($detail.BotTaskAction)" 'OK'
    } catch {
        Write-Log "BotRules task error: $_" 'ERROR'
        $detail = Get-TaskProofObject -Name 'ChknMinerBotRules' -Attempted $true -Succeeded $false
        $detail['error'] = [string]$_
        Add-Result 'BotRules-Task' $false $detail
        Add-Result 'Step7-BotRules' $false ([ordered]@{
            TaskName = 'ChknMinerBotRules'
            TaskPresent = [bool](Test-Path -LiteralPath $rules)
            TaskRegistered = $false
            TaskStartAttempted = $true
            TaskStartResult = 'FAIL'
            EvidencePath = $LogPath
            Error = [string]$_
        })
        throw
    }
}
if(-not $SkipConditionMonitor){
    Step-Banner 'Step 7: Register condition monitor'
    $cond = Join-Path $RuntimePackageRoot 'ChknMiner-Condition-Monitor.ps1'
    Write-Log "Condition script: $(if(Test-Path $cond){'EXISTS'}else{'MISSING'}) $cond" 'DEBUG'

    try{
        Write-Log "Registering Condition Monitor task" 'INFO'
        $ensure = Invoke-EnsureManagerTask -TaskName 'ChknMinerConditionMonitor' -ScriptPath $cond -Minutes 5
        $detail = $ensure.Detail
        Add-Result 'ConditionMonitor-Task' $true $detail
        Add-Result 'Step7-ConditionMonitor' $true ([ordered]@{
            TaskName = 'ChknMinerConditionMonitor'
            TaskPresent = $true
            TaskRegistered = $true
            TaskStartAttempted = $true
            TaskStartResult = 'SUCCESS'
            EvidencePath = $LogPath
            Error = ''
        })
        Write-Log "Condition monitor task ensured. action=$($detail.BotTaskAction)" 'OK'
    } catch {
        Write-Log "Condition monitor task error: $_" 'ERROR'
        $detail = Get-TaskProofObject -Name 'ChknMinerConditionMonitor' -Attempted $true -Succeeded $false
        $detail['error'] = [string]$_
        Add-Result 'ConditionMonitor-Task' $false $detail
        Add-Result 'Step7-ConditionMonitor' $false ([ordered]@{
            TaskName = 'ChknMinerConditionMonitor'
            TaskPresent = [bool](Test-Path -LiteralPath $cond)
            TaskRegistered = $false
            TaskStartAttempted = $true
            TaskStartResult = 'FAIL'
            EvidencePath = $LogPath
            Error = [string]$_
        })
        throw
    }
}
if(-not $SkipConditionMonitor){
    Invoke-PostInstallConditionMonitorRun
}
Invoke-PostInstallTruth
Step-Banner 'Summary'
foreach($r in $results){ Write-Log ("{0}: {1} {2}" -f $r.Step,$r.Success,$r.Detail) }
Write-Log "Authoritative proof file: $ProofPath" 'OK'
Write-Log "Latest proof pointer: $LatestProofPath" 'OK'
$hasFailure = [bool]($results | Where-Object { -not $_.Success })
$hasStep6 = [bool](@($results | Where-Object { $_.Step -eq 'Step6-UpdaterAgent' }).Count -gt 0)
$hasStep7A = [bool](@($results | Where-Object { $_.Step -eq 'Step7-BotRules' }).Count -gt 0)
$hasStep7B = [bool](@($results | Where-Object { $_.Step -eq 'Step7-ConditionMonitor' }).Count -gt 0)
if (-not $hasStep6) {
    Add-Result 'Step6-UpdaterAgent' $false ([ordered]@{ Error = 'MISSING_STRUCTURED_STAGE'; EvidencePath = $LogPath })
    $hasFailure = $true
}
if (-not $hasStep7A) {
    Add-Result 'Step7-BotRules' $false ([ordered]@{ Error = 'MISSING_STRUCTURED_STAGE'; EvidencePath = $LogPath })
    $hasFailure = $true
}
if (-not $hasStep7B) {
    Add-Result 'Step7-ConditionMonitor' $false ([ordered]@{ Error = 'MISSING_STRUCTURED_STAGE'; EvidencePath = $LogPath })
    $hasFailure = $true
}
if($EvidenceExportFailed){
    $hasFailure = $true
    Add-Result 'POST-Evidence-Export' $false ([ordered]@{
        reason = $EvidenceExportFailureReason
    })
} else {
    Add-Result 'POST-Evidence-Export' $true 'validated'
}
if($hasFailure){
    Write-FinalStatusRecord -Outcome 'FAIL' -ExitCode 1 -ErrorText 'One or more installer stages failed.'
    Invoke-OneDriveEvidenceExport -Outcome 'FAIL'
    exit 1
}
Write-FinalStatusRecord -Outcome 'PASS' -ExitCode 0 -ErrorText ''
Invoke-OneDriveEvidenceExport -Outcome 'PASS'
exit 0
