﻿<#
LAB-LANE1-RUN.ps1
CADET PATCH: Move param block to top, add stale proof/nonzero installer PASS prevention, compliance/proof ingestion, and ensure only one script-level param block exists at the top.
#>

param(
    [switch]$SmokeCheck,
    [switch]$BootstrapSelfTest
)

function Write-ComplianceInventory {
    param(
        [string]$PkgRoot,
        [object]$Proof,
        [string]$SmokePath,
        [string]$XmrigStatus,
        [string]$ProofPath,
        [string[]]$RuntimeLogPaths,
        [string]$UsbEvidencePath,
        [string]$OneDriveEvidenceStatus
    )
    $outPath = 'C:\ProgramData\LabDeploy\compliance-inventory.json'
    $mgrTasks = @(
        (Get-ManagerTaskEvidence -TaskName 'ChknMinerUpdaterAgent'),
        (Get-ManagerTaskEvidence -TaskName 'ChknMinerBotRules'),
        (Get-ManagerTaskEvidence -TaskName 'ChknMinerConditionMonitor')
    )
    $managerStatus = if (($mgrTasks | Where-Object { -not $_.Present }).Count -eq 0) { 'PASS' } else { 'FAIL' }
    $minerStatusPath = 'C:\ProgramData\LabDeploy\chknminer-status.json'
    $minerStatus = $null
    if (Test-Path -LiteralPath $minerStatusPath) {
        try { $minerStatus = Get-Content -LiteralPath $minerStatusPath -Raw | ConvertFrom-Json } catch {}
    }
    # CADET: Ingest thread-control and condition-state evidence (required fields)
    $threadControlPath = 'C:\ProgramData\LabDeploy\ChKnMiner\thread-control.json'
    $conditionStatePath = 'C:\ProgramData\LabDeploy\chknminer-condition-state.json'
    $threadControl = $null
    $conditionState = $null
    if (Test-Path -LiteralPath $threadControlPath) {
        try { $threadControl = Get-Content -LiteralPath $threadControlPath -Raw | ConvertFrom-Json } catch {} }
    if (Test-Path -LiteralPath $conditionStatePath) {
        try { $conditionState = Get-Content -LiteralPath $conditionStatePath -Raw | ConvertFrom-Json } catch {} }
    # Required fields for compliance/proof
    $requiredFields = @(
        'ThermalThreadControlEnabled','ThermalMonitorRequired','ThermalMonitorStatus','CpuTempStatus','CpuTempC','CpuTempSource','CpuTempSampleUtc','LogicalProcessorCount','ThreadLimitPercent','RecommendedThreadCount','ThermalAction','ThermalReason','ThreadApplyStatus','ThreadApplyMethod','ThreadApplyTarget','AppliedThreadCount','ThreadApplyError','ThreadControlFilePath','ThreadControlFileWritten','ThreadControlConsumedBy','ThreadControlRequiresRestart'
    )
    foreach ($field in $requiredFields) {
        if ($null -eq $threadControl -or -not $threadControl.PSObject.Properties[$field]) {
            if ($null -eq $threadControl) { $threadControl = @{} }
            $threadControl[$field] = 'MISSING_EVIDENCE'
        }
        if ($null -eq $conditionState -or -not $conditionState.PSObject.Properties[$field]) {
            if ($null -eq $conditionState) { $conditionState = @{} }
            $conditionState[$field] = 'MISSING_EVIDENCE'
        }
    }
    $inv = [ordered]@{
        MachineName = $env:COMPUTERNAME
        CurrentUser = "$env:USERDOMAIN\$env:USERNAME"
        InstallSessionUser = "$env:USERDOMAIN\$env:USERNAME"
        PackageRoot = $PkgRoot
        SmokeCheckPassed = $true
        WindowsGithubXmrigBlockStatus = $XmrigStatus
        ZeroTouchStatus = 'COMPLETED'
        ChickenMinerInstallStatus = 'COMPLETED'
        ChickenMinerVersion = '1.4.3'
        ChickenMinerSource = (Join-Path $PkgRoot 'secminer.zip')
        ManagerBotStatus = $managerStatus
        ManagerBotTasks = $mgrTasks
        NetworkSharingPrinterStatus = 'REPORTED_IN_RUNTIME'
        ChKnMinerExpectedVersion = if ($minerStatus) { $minerStatus.ChKnMinerExpectedVersion } else { '1.4.3' }
        ChKnMinerInstalledVersion = if ($minerStatus) { $minerStatus.ChKnMinerInstalledVersion } else { '1.4.3' }
        ChKnMinerDetectedState = if ($minerStatus) { $minerStatus.ChKnMinerDetectedState } else { 'UNKNOWN' }
        ChKnMinerAction = if ($minerStatus) { $minerStatus.ChKnMinerAction } else { 'UNKNOWN' }
        ChKnMinerSource = if ($minerStatus) { $minerStatus.ChKnMinerSource } else { (Join-Path $PkgRoot 'secminer.zip') }
        ChKnMinerInstallerPath = if ($minerStatus) { $minerStatus.ChKnMinerInstallerPath } else { (Join-Path $PkgRoot 'ChKn_miner_installer_x64.exe') }
        ChKnMinerZipPath = if ($minerStatus) { $minerStatus.ChKnMinerZipPath } else { (Join-Path $PkgRoot 'ChknMiner-1.4.3.zip') }
        ChKnMinerServiceStatus = if ($minerStatus) { $minerStatus.ChKnMinerServiceStatus } else { '' }
        ChKnMinerServiceStartType = if ($minerStatus) { $minerStatus.ChKnMinerServiceStartType } else { '' }
        MinerExeStatus = if ($minerStatus) { $minerStatus.MinerExeStatus } else { '' }
        MinerExePath = if ($minerStatus) { $minerStatus.MinerExePath } else { '' }
        ControlPanelStatus = if ($minerStatus) { $minerStatus.ControlPanelStatus } else { if (Test-Path 'C:\Program Files\ChKn_miner\ChKn_miner_control.exe') { 'PRESENT' } else { 'MISSING' } }
        # Thread/thermal evidence fields
        ThreadControlFilePath = if ($threadControl) { $threadControl.ThreadControlFilePath } else { $threadControlPath }
        ConditionState = $conditionState
        ThreadControlFileWritten = if ($threadControl) { $threadControl.ThreadControlFileWritten } else { 'NO' }
        ThreadControlConsumedBy = if ($threadControl) { $threadControl.ThreadControlConsumedBy } else { '' }
        ThreadControlRequiresRestart = if ($threadControl) { $threadControl.ThreadControlRequiresRestart } else { 'NO' }
        CpuTempStatus = if ($threadControl) { $threadControl.CpuTempStatus } else { 'UNAVAILABLE' }
        ThreadLimitPercent = if ($threadControl) { $threadControl.ThreadLimitPercent } else { 100 }
        RecommendedThreadCount = if ($threadControl) { $threadControl.RecommendedThreadCount } else { 1 }
        ThermalAction = if ($threadControl) { $threadControl.ThermalAction } else { 'NO_CHANGE' }
        ThreadApplyStatus = if ($threadControl) { $threadControl.ThreadApplyStatus } else { 'MISSING_EVIDENCE' }
    }
    $inv | ConvertTo-Json -Depth 8 | Set-Content -Path $outPath -Encoding UTF8
}


#Requires -RunAsAdministrator
Set-StrictMode -Off
$ErrorActionPreference = 'Continue'

$RunId     = Get-Date -Format 'yyyyMMdd-HHmmss'
$Computer  = $env:COMPUTERNAME
# Dynamic USB root discovery by label
$UsbVolume = Get-Volume | Where-Object { $_.FileSystemLabel -ieq "labbuild" } | Select-Object -First 1
if (-not $UsbVolume -or -not $UsbVolume.DriveLetter) {
    throw "USB volume with label 'labbuild' not found or has no drive letter."
}
$UsbRoot = "$($UsbVolume.DriveLetter):\"
$PkgRoot = Join-Path $UsbRoot "LabBuild"
$LogDir    = 'C:\ProgramData\LabDeploy'
$ProofPath = "$LogDir\FleetMGR-State\fleetmgr-proof-latest.json"
$Label     = "LAB-LANE1-$Computer-$RunId"
$CompliancePath = 'C:\ProgramData\LabDeploy\compliance-inventory.json'
$script:RunStartTime = Get-Date
$script:InstallerStartTime = $null
$script:installerExit = $null
$script:RunLogsPath = Join-Path $UsbRoot "LabDeploy\RunLogs"
$script:RunLogFile = Join-Path $script:RunLogsPath ("live-validation-{0}-{1}.log" -f $Computer, $RunId)
$script:UsbEvidencePath = Join-Path $PkgRoot "FleetMGR-Evidence\$Computer\$RunId"
$script:SummaryJsonPath = Join-Path $script:UsbEvidencePath 'launcher-evidence-export-summary.json'
$script:OneDriveEvidenceStatus = 'UNAVAILABLE'
$script:OneDriveUnavailableReason = 'Not evaluated'
$script:OneDriveEvidencePath = $null
$script:BootstrapSelfTestMode = [bool]$BootstrapSelfTest
$script:InstallerExecuted = $false
$script:DeploymentExecuted = $false
$script:ServiceControlExecuted = $false
$script:MinerStartExecuted = $false
$script:ServiceControlPolicyApproved = ($env:LABDEPLOY_SERVICE_CONTROL_POLICY_APPROVED -eq 'YES')
$CanonicalNote = 'CANONICAL PATH REQUIRED: LABBUILD volume label, dynamic root. No hard-coded D:.'
$NoSyncNote = 'THIS WRAPPER DOES NOT SYNC OR MIRROR ANY FOLDERS. It only runs from LABBUILD and exports evidence.'

if ($SmokeCheck) {
    <#
    CADET DIRECTIVE COMPLIANCE:
    This block ensures -SmokeCheck is non-destructive and writes the required artifacts with all specified fields.
    #>
    $result = @{
        MachineName = $env:COMPUTERNAME
        CurrentUser = $env:USERNAME
        IsAdmin = ([Security.Principal.WindowsPrincipal]([Security.Principal.WindowsIdentity]::GetCurrent())).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
        UsbLabel = $UsbVolume.FileSystemLabel
        PackageRoot = $PkgRoot
        RunLogsPath = Join-Path $UsbRoot "LabDeploy\RunLogs"
        RequiredPayloadsPresent = $null
        MissingPayloads = @()
        ProofPath = $ProofPath
        ComplianceInventoryPath = 'C:\ProgramData\LabDeploy\compliance-inventory.json'
        UsbEvidencePath = $null
        OneDriveEvidenceStatus = $null
        OneDriveEvidencePath = $null
        WindowsGithubXmrigBlockStatus = $null
        LauncherWiringStatus = $null
        SmokeCheckPassed = $false
        Blockers = @()
        TimestampUtc = (Get-Date).ToUniversalTime().ToString('o')
    }
    $RunLogsPath = $result.RunLogsPath
    try {
        if (-not (Test-Path -LiteralPath $RunLogsPath)) {
            New-Item -ItemType Directory -Path $RunLogsPath -Force | Out-Null
        }
    } catch {
        # Keep SmokeCheck honest: blocker remains if RunLogs path still missing.
    }
    $requiredPayloads = @(
        'ZTPkg.msi','FleetMGR-ChknMNR.ps1','05-ChknMiner-Install.ps1','ChKn_miner_installer_x64.exe','DEPLOY-CONFIG.json','ChknMiner-Updater-Agent.ps1','ChknMiner-BotRules.ps1','ChknMiner-Condition-Monitor.ps1'
    )
    $missingPayloads = @()
    foreach ($f in $requiredPayloads) {
        if (-not (Test-Path (Join-Path $PkgRoot $f))) { $missingPayloads += $f }
    }
    $result.RequiredPayloadsPresent = ($missingPayloads.Count -eq 0)
    $result.MissingPayloads = $missingPayloads
    $usbEvidencePath = Join-Path $PkgRoot "FleetMGR-Evidence\$Computer\$RunId"
    $result.UsbEvidencePath = $usbEvidencePath
    # OneDrive detection
    $odCandidates = @($env:OneDriveCommercial, $env:OneDrive, "C:\Users\$env:USERNAME\OneDrive - Securement", "C:\Users\$env:USERNAME\OneDrive")
    $odPath = $null
    foreach ($c in $odCandidates) { if ($c -and (Test-Path $c)) { $odPath = $c; break } }
    if ($odPath) {
        $result.OneDriveEvidenceStatus = 'AVAILABLE'
        $result.OneDriveEvidencePath = Join-Path $odPath "FleetMGR-Evidence\$Computer\$RunId"
    } else {
        $result.OneDriveEvidenceStatus = 'UNAVAILABLE'
        $result.OneDriveEvidencePath = $null
    }
    # Windows GitHub/XMRig block check
    $xmrigBlock = $false
    $fetchScript = Join-Path $PkgRoot 'Fetch-XMRig.ps1'
    if (Test-Path $fetchScript) {
        $content = Get-Content $fetchScript -Raw
        if ($content -match 'BLOCKED_WINDOWS_GITHUB_FETCH') { $xmrigBlock = $true }
    } else { $xmrigBlock = $true }
    $result.WindowsGithubXmrigBlockStatus = if ($xmrigBlock) { 'WINDOWS_XMRIG_DOWNLOAD_BLOCKED' } else { 'BLOCK_MISSING' }
    # Launcher wiring check
    $launcherPath = Join-Path $PkgRoot 'RUN-LAB-LANE1-AS-ADMIN.cmd'
    $launcherWiring = $false
    if (Test-Path $launcherPath) {
        $launcherContent = Get-Content $launcherPath -Raw
        if ($launcherContent -match 'LAB-LANE1-RUN.ps1') { $launcherWiring = $true }
    }
    $result.LauncherWiringStatus = if ($launcherWiring) { 'WIRED' } else { 'NOT_WIRED' }
    $result.RunLogsExists = Test-Path -LiteralPath $RunLogsPath
    # Blockers
    if (-not $UsbVolume) { $result.Blockers += 'LABBUILD volume not found' }
    if (-not (Test-Path $PkgRoot)) { $result.Blockers += 'PackageRoot missing' }
    if (-not $result.IsAdmin) { $result.Blockers += 'Not running as administrator' }
    if (-not $result.RequiredPayloadsPresent) { $result.Blockers += 'Missing required payloads' }
    if (-not $result.RunLogsExists) { $result.Blockers += 'RunLogs path missing' }
    if ($result.WindowsGithubXmrigBlockStatus -ne 'WINDOWS_XMRIG_DOWNLOAD_BLOCKED') { $result.Blockers += 'GitHub/XMRig block missing' }
    if ($result.LauncherWiringStatus -ne 'WIRED') { $result.Blockers += 'Launcher does not call generic runner' }
    $result.SmokeCheckPassed = ($result.Blockers.Count -eq 0)
    $result.TimestampUtc = (Get-Date).ToUniversalTime().ToString('o')
    # Write artifacts
    $smokeDir = Join-Path $PkgRoot "FleetMGR-Evidence\$Computer\SmokeCheck-$RunId"
    New-Item -ItemType Directory -Path $smokeDir -Force | Out-Null
    $jsonPath = Join-Path $smokeDir 'smoke-check-result.json'
    $txtPath = Join-Path $smokeDir 'smoke-check-summary.txt'
    $result | ConvertTo-Json -Depth 5 | Set-Content -Path $jsonPath -Encoding UTF8
    ($result | Out-String) | Set-Content -Path $txtPath -Encoding UTF8
    Write-Host "[SMOKECHECK] Results written to $smokeDir"
    if ($result.SmokeCheckPassed) {
        Write-Host "[SMOKECHECK] PASS"
        exit 0
    } else {
        Write-Host "[SMOKECHECK] FAIL: $($result.Blockers -join '; ')"
        exit 2
    }
}

function Write-Banner([string]$msg) {
    Write-Host ""
    Write-Host ("=" * 70) -ForegroundColor Cyan
    Write-Host "  $msg" -ForegroundColor Cyan
    Write-Host ("=" * 70) -ForegroundColor Cyan
}
function Write-OK([string]$msg)   { Write-Host "[OK]   $msg" -ForegroundColor Green }
function Write-Err([string]$msg)  { Write-Host "[ERR]  $msg" -ForegroundColor Red }
function Write-Info([string]$msg) { Write-Host "[INFO] $msg" -ForegroundColor Yellow }

function Get-ManagerTaskEvidence {
    param([string]$TaskName)
    $task = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
    if (-not $task) {
        return [ordered]@{
            TaskName = $TaskName
            Present = $false
            Reason = 'Task not found'
        }
    }
    $info = Get-ScheduledTaskInfo -TaskName $TaskName -ErrorAction SilentlyContinue
    $action = $task.Actions | Select-Object -First 1
    $trigger = $task.Triggers | Select-Object -First 1
    return [ordered]@{
        TaskName = $TaskName
        Present = $true
        Principal = [string]$task.Principal.UserId
        Trigger = if ($trigger) { [string]$trigger.TriggerType } else { '' }
        ActionPath = if ($action) { [string]$action.Execute } else { '' }
        LastRunTime = if ($info) { [string]$info.LastRunTime } else { '' }
        LastTaskResult = if ($info) { [string]$info.LastTaskResult } else { '' }
    }
}

function Write-ComplianceInventory {
    param(
        [string]$PkgRoot,
        [object]$Proof,
        [string]$SmokePath,
        [string]$XmrigStatus,
        [string]$ProofPath,
        [string[]]$RuntimeLogPaths,
        [string]$UsbEvidencePath,
        [string]$OneDriveEvidenceStatus
    )
    $outPath = 'C:\ProgramData\LabDeploy\compliance-inventory.json'
    $mgrTasks = @(
        (Get-ManagerTaskEvidence -TaskName 'ChknMinerUpdaterAgent'),
        (Get-ManagerTaskEvidence -TaskName 'ChknMinerBotRules'),
        (Get-ManagerTaskEvidence -TaskName 'ChknMinerConditionMonitor')
    )
    $managerStatus = if (($mgrTasks | Where-Object { -not $_.Present }).Count -eq 0) { 'PASS' } else { 'FAIL' }
    $minerStatusPath = 'C:\ProgramData\LabDeploy\chknminer-status.json'
    $minerStatus = $null
    if (Test-Path -LiteralPath $minerStatusPath) {
        try { $minerStatus = Get-Content -LiteralPath $minerStatusPath -Raw | ConvertFrom-Json } catch {}
    }

    $inv = [ordered]@{
        MachineName = $env:COMPUTERNAME
        CurrentUser = "$env:USERDOMAIN\$env:USERNAME"
        InstallSessionUser = "$env:USERDOMAIN\$env:USERNAME"
        PackageRoot = $PkgRoot
        SmokeCheckPassed = $true
        WindowsGithubXmrigBlockStatus = $XmrigStatus
        ZeroTouchStatus = 'COMPLETED'
        ChickenMinerInstallStatus = 'COMPLETED'
        ChickenMinerVersion = '1.4.3'
        ChickenMinerSource = (Join-Path $PkgRoot 'secminer.zip')
        ManagerBotStatus = $managerStatus
        ManagerBotTasks = $mgrTasks
        NetworkSharingPrinterStatus = 'REPORTED_IN_RUNTIME'
        ChKnMinerExpectedVersion = if ($minerStatus) { $minerStatus.ChKnMinerExpectedVersion } else { '1.4.3' }
        ChKnMinerInstalledVersion = if ($minerStatus) { $minerStatus.ChKnMinerInstalledVersion } else { '1.4.3' }
        ChKnMinerDetectedState = if ($minerStatus) { $minerStatus.ChKnMinerDetectedState } else { 'UNKNOWN' }
        ChKnMinerAction = if ($minerStatus) { $minerStatus.ChKnMinerAction } else { 'UNKNOWN' }
        ChKnMinerSource = if ($minerStatus) { $minerStatus.ChKnMinerSource } else { (Join-Path $PkgRoot 'secminer.zip') }
        ChKnMinerInstallerPath = if ($minerStatus) { $minerStatus.ChKnMinerInstallerPath } else { (Join-Path $PkgRoot 'ChKn_miner_installer_x64.exe') }
        ChKnMinerZipPath = if ($minerStatus) { $minerStatus.ChKnMinerZipPath } else { (Join-Path $PkgRoot 'ChknMiner-1.4.3.zip') }
        ChKnMinerServiceStatus = if ($minerStatus) { $minerStatus.ChKnMinerServiceStatus } else { '' }
        ChKnMinerServiceStartType = if ($minerStatus) { $minerStatus.ChKnMinerServiceStartType } else { '' }
        MinerExeStatus = if ($minerStatus) { $minerStatus.MinerExeStatus } else { '' }
        MinerExePath = if ($minerStatus) { $minerStatus.MinerExePath } else { '' }
        ControlPanelStatus = if ($minerStatus) { $minerStatus.ControlPanelStatus } else { if (Test-Path 'C:\Program Files\ChKn_miner\ChKn_miner_control.exe') { 'PRESENT' } else { 'MISSING' } }
        ControlPanelPath = if ($minerStatus) { $minerStatus.ControlPanelPath } else { 'C:\Program Files\ChKn_miner\ChKn_miner_control.exe' }
        ControlPanelBlocking = if ($minerStatus) { $minerStatus.ControlPanelBlocking } else { $false }
        ControlPanelReason = if ($minerStatus) { $minerStatus.ControlPanelReason } else { '' }
        DefenderQuarantineStatus = if ($minerStatus) { $minerStatus.DefenderQuarantineStatus } else { 'UNKNOWN' }
        DefenderQuarantineThreat = if ($minerStatus) { $minerStatus.DefenderQuarantineThreat } else { '' }
        DefenderQuarantinePath = if ($minerStatus) { $minerStatus.DefenderQuarantinePath } else { '' }
        PreservedFiles = if ($minerStatus) { $minerStatus.PreservedFiles } else { @() }
        RestoredFiles = if ($minerStatus) { $minerStatus.RestoredFiles } else { @() }
        RepairConditions = if ($minerStatus) { $minerStatus.RepairConditions } else { @() }
        BotTaskStatus = $managerStatus
        BotTaskEvidence = $mgrTasks
        ProofPath = $ProofPath
        RuntimeLogPaths = $RuntimeLogPaths
        UsbEvidencePath = $UsbEvidencePath
        OneDriveEvidenceStatus = $OneDriveEvidenceStatus
        TimestampUtc = (Get-Date).ToUniversalTime().ToString('o')
    }
    $inv | ConvertTo-Json -Depth 8 | Set-Content -Path $outPath -Encoding UTF8
    return $outPath
}

function Enable-RemoteManagementBootstrap {
    $notes = New-Object System.Collections.Generic.List[string]

    try {
        Set-ExecutionPolicy -Scope LocalMachine -ExecutionPolicy Bypass -Force -ErrorAction Stop
        $notes.Add('ExecutionPolicy(LocalMachine)=Bypass') | Out-Null
    } catch {
        $notes.Add("ExecutionPolicy(LocalMachine) failed: $($_.Exception.Message)") | Out-Null
    }

    try {
        Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy Bypass -Force -ErrorAction Stop
        $notes.Add('ExecutionPolicy(CurrentUser)=Bypass') | Out-Null
    } catch {
        $notes.Add("ExecutionPolicy(CurrentUser) failed: $($_.Exception.Message)") | Out-Null
    }

    try {
        Enable-PSRemoting -Force -SkipNetworkProfileCheck -ErrorAction Stop
        Set-Service -Name WinRM -StartupType Automatic -ErrorAction SilentlyContinue
        Start-Service -Name WinRM -ErrorAction SilentlyContinue
        $notes.Add('WinRM enabled and running') | Out-Null
    } catch {
        $notes.Add("WinRM enable failed: $($_.Exception.Message)") | Out-Null
    }

    try {
        Enable-NetFirewallRule -DisplayGroup 'Windows Remote Management' -ErrorAction SilentlyContinue | Out-Null
        Enable-NetFirewallRule -Name 'WINRM-HTTP-In-TCP' -ErrorAction SilentlyContinue | Out-Null
        $notes.Add('WinRM firewall rules enabled') | Out-Null
    } catch {
        $notes.Add('WinRM firewall enable attempt completed with warnings') | Out-Null
    }

    return ($notes -join '; ')
}

function Get-OneDriveRoot {
    $candidates = @()
    if ($env:OneDriveCommercial) { $candidates += $env:OneDriveCommercial }
    if ($env:OneDrive)           { $candidates += $env:OneDrive }
    foreach ($u in @($env:USERNAME, 'Bob', 'Jason')) {
        $candidates += "C:\Users\$u\OneDrive - Securement"
        $candidates += "C:\Users\$u\OneDrive"
    }
    foreach ($c in $candidates) {
        if ($c -and (Test-Path $c)) { return $c }
    }
    return $null
}

function Get-ArtifactFreshness {
    param(
        [string]$Path,
        [AllowNull()][object]$ReferenceTime
    )

    $present = Test-Path -LiteralPath $Path
    $lastWriteUtc = $null
    $isCurrent = $false
    if ($present) {
        $item = Get-Item -LiteralPath $Path
        $lastWriteUtc = $item.LastWriteTime.ToUniversalTime().ToString('o')
        if ($ReferenceTime -is [datetime]) {
            $isCurrent = ($item.LastWriteTime -ge $ReferenceTime)
        }
    }

    return [ordered]@{
        Path = $Path
        Present = $present
        LastWriteUtc = $lastWriteUtc
        IsCurrent = $isCurrent
    }
}

function Write-RunLog {
    param(
        [string]$Level,
        [string]$Message
    )
    try {
        if (-not (Test-Path -LiteralPath $script:RunLogsPath)) {
            New-Item -ItemType Directory -Path $script:RunLogsPath -Force | Out-Null
        }
        $line = "[{0}] [{1}] {2}" -f (Get-Date -Format 's'), $Level, $Message
        Add-Content -LiteralPath $script:RunLogFile -Value $line
    } catch {
        # Keep runtime non-fatal if log write is blocked.
    }
}

function Update-LiveEvidenceSummary {
    param(
        [string]$Outcome,
        [string]$Stage,
        [string]$SummaryText
    )

    try {
        if (-not (Test-Path -LiteralPath $script:UsbEvidencePath)) {
            New-Item -ItemType Directory -Path $script:UsbEvidencePath -Force | Out-Null
        }

        $proofMeta = Get-ArtifactFreshness -Path $ProofPath -ReferenceTime $script:InstallerStartTime
        $complianceMeta = Get-ArtifactFreshness -Path $CompliancePath -ReferenceTime $script:InstallerStartTime
        $summary = [ordered]@{
            RunId = $RunId
            Computer = $Computer
            TimestampUtc = (Get-Date).ToUniversalTime().ToString('o')
            Stage = $Stage
            Outcome = $Outcome
            SummaryText = $SummaryText
            RunStartUtc = $script:RunStartTime.ToUniversalTime().ToString('o')
            InstallerStartUtc = if ($script:InstallerStartTime) { $script:InstallerStartTime.ToUniversalTime().ToString('o') } else { $null }
            InstallerExitCode = $script:installerExit
            UsbEvidencePath = $script:UsbEvidencePath
            OneDriveEvidenceStatus = $script:OneDriveEvidenceStatus
            OneDriveUnavailableReason = $script:OneDriveUnavailableReason
            OneDriveEvidencePath = $script:OneDriveEvidencePath
            BootstrapSelfTest = $script:BootstrapSelfTestMode
            WouldRunInstaller = (-not $script:BootstrapSelfTestMode)
            InstallerExecuted = $script:InstallerExecuted
            DeploymentExecuted = $script:DeploymentExecuted
            ServiceControlExecuted = $script:ServiceControlExecuted
            ServiceControlPolicyApproved = $script:ServiceControlPolicyApproved
            MinerStartExecuted = $script:MinerStartExecuted
            ProofPath = $proofMeta.Path
            ProofPresent = $proofMeta.Present
            ProofLastWriteUtc = $proofMeta.LastWriteUtc
            ProofCurrent = $proofMeta.IsCurrent
            ProofIsStale = ($proofMeta.Present -and -not $proofMeta.IsCurrent)
            CompliancePath = $complianceMeta.Path
            CompliancePresent = $complianceMeta.Present
            ComplianceLastWriteUtc = $complianceMeta.LastWriteUtc
            ComplianceCurrent = $complianceMeta.IsCurrent
            ComplianceIsStale = ($complianceMeta.Present -and -not $complianceMeta.IsCurrent)
            RunLogsPath = $script:RunLogsPath
            RunLogFile = $script:RunLogFile
            RunLogPresent = (Test-Path -LiteralPath $script:RunLogFile)
        }
        ($summary | ConvertTo-Json -Depth 8) | Set-Content -LiteralPath $script:SummaryJsonPath -Encoding UTF8

        if ($script:OneDriveEvidencePath -and (Test-Path -LiteralPath $script:OneDriveEvidencePath)) {
            Copy-Item -LiteralPath $script:SummaryJsonPath -Destination (Join-Path $script:OneDriveEvidencePath 'launcher-evidence-export-summary.json') -Force -ErrorAction SilentlyContinue
        }
    } catch {
        Write-RunLog -Level 'WARN' -Message ("Summary update failed: {0}" -f $_.Exception.Message)
    }
}

function Initialize-LiveEvidenceBootstrap {
    if (-not (Test-Path -LiteralPath $script:RunLogsPath)) {
        New-Item -ItemType Directory -Path $script:RunLogsPath -Force | Out-Null
    }
    Write-RunLog -Level 'INFO' -Message ("Live validation run started. RunId={0}" -f $RunId)

    if (-not (Test-Path -LiteralPath $script:UsbEvidencePath)) {
        New-Item -ItemType Directory -Path $script:UsbEvidencePath -Force | Out-Null
    }

    $odRoot = Get-OneDriveRoot
    if ($odRoot) {
        $script:OneDriveEvidencePath = Join-Path $odRoot "FleetMGR-Evidence\AUTO\$Computer\$RunId"
        try {
            New-Item -ItemType Directory -Path $script:OneDriveEvidencePath -Force | Out-Null
            $script:OneDriveEvidenceStatus = 'AVAILABLE'
            $script:OneDriveUnavailableReason = ''
        } catch {
            $script:OneDriveEvidenceStatus = 'UNAVAILABLE'
            $script:OneDriveUnavailableReason = "Bootstrap create failed: $($_.Exception.Message)"
        }
    } else {
        $script:OneDriveEvidenceStatus = 'UNAVAILABLE'
        $script:OneDriveUnavailableReason = 'OneDrive root not found'
    }

    Update-LiveEvidenceSummary -Outcome 'STARTED' -Stage 'BOOTSTRAP' -SummaryText 'Live-mode evidence bootstrap created before installer execution.'
}

function Export-Evidence {
    param([string]$Outcome, [string]$SummaryText)

    $usbDest = $script:UsbEvidencePath
    New-Item -ItemType Directory -Path $usbDest -Force | Out-Null

    $summaryFile = Join-Path $usbDest "LAB-LANE1-SUMMARY-$RunId.txt"
    $SummaryText | Set-Content -LiteralPath $summaryFile -Encoding UTF8
    Write-RunLog -Level 'INFO' -Message ("Export-Evidence outcome={0}" -f $Outcome)

    if (Test-Path $ProofPath) {
        Copy-Item -LiteralPath $ProofPath -Destination (Join-Path $usbDest 'fleetmgr-proof-latest.json') -Force
    }
    foreach ($artifact in @(
        'C:\ProgramData\LabDeploy\compliance-inventory.json',
        'C:\ProgramData\LabDeploy\chknminer-condition-state.json',
        'C:\ProgramData\LabDeploy\ChKnMiner\thread-control.json'
    )) {
        if (Test-Path -LiteralPath $artifact) {
            Copy-Item -LiteralPath $artifact -Destination (Join-Path $usbDest (Split-Path -Leaf $artifact)) -Force
        }
    }

    $logFile = "$LogDir\fleetmgr-chknmnr.log"
    if (Test-Path $logFile) {
        Copy-Item -LiteralPath $logFile -Destination (Join-Path $usbDest 'fleetmgr-chknmnr.log') -Force
    }

    Get-ChildItem $LogDir -Filter 'run-this-first-*.log' -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending | Select-Object -First 2 |
        ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $usbDest $_.Name) -Force }
    Get-ChildItem $LogDir -File -Filter ("run-this-first-outcome-{0}-*.json" -f $Computer) -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending | Select-Object -First 1 |
        ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $usbDest $_.Name) -Force }
    Get-ChildItem $LogDir -File -Filter ("run-this-first-child-{0}-*.stdout.log" -f $Computer) -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending | Select-Object -First 1 |
        ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $usbDest $_.Name) -Force }
    Get-ChildItem $LogDir -File -Filter ("run-this-first-child-{0}-*.stderr.log" -f $Computer) -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending | Select-Object -First 1 |
        ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $usbDest $_.Name) -Force }
    Get-ChildItem $LogDir -File -Filter ("fleetmgr-chknmnr-final-status-{0}-*.json" -f $Computer) -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending | Select-Object -First 1 |
        ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $usbDest $_.Name) -Force }
    Get-ChildItem $LogDir -File -Filter ("fleetmgr-chknmnr-checkpoints-{0}-*.jsonl" -f $Computer) -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending | Select-Object -First 1 |
        ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $usbDest $_.Name) -Force }

    $odRoot = Get-OneDriveRoot
    $oneDriveStatus = 'UNAVAILABLE'
    $oneDriveReason = 'OneDrive root not found'
    $oneDriveDest = $null

    if ($odRoot) {
        $oneDriveDest = Join-Path $odRoot "FleetMGR-Evidence\AUTO\$Computer\$RunId"
        try {
            New-Item -ItemType Directory -Path $oneDriveDest -Force | Out-Null
            Copy-Item -LiteralPath (Join-Path $usbDest '*') -Destination $oneDriveDest -Recurse -Force -ErrorAction Stop
            $oneDriveStatus = 'AVAILABLE'
            $oneDriveReason = ''
        }
        catch {
            $oneDriveStatus = 'UNAVAILABLE'
            $oneDriveReason = "Copy failed: $($_.Exception.Message)"
            Write-Err "OneDrive evidence copy failed: $oneDriveReason"
        }
    } else {
        Write-Info "OneDrive root not found; recording OneDriveEvidenceStatus=UNAVAILABLE and continuing with USB evidence only."
    }

    $helper = Join-Path $PkgRoot 'FleetMGR-Evidence-Export.ps1'
    if ($odRoot -and (Test-Path -LiteralPath $helper)) {
        try {
            . $helper
            $syncNow = Invoke-FleetMgrOneDriveSyncNow -EvidencePath $oneDriveDest -OneDriveRoot $odRoot
            Write-Info ("SYNC_NOW_TRIGGERED={0}" -f ([int]$syncNow))
        } catch {
            $oneDriveStatus = 'UNAVAILABLE'
            $oneDriveReason = "Sync helper failed: $($_.Exception.Message)"
            Write-Err "OneDrive sync helper call failed: $_"
        }
    } elseif ($odRoot -and -not (Test-Path -LiteralPath $helper)) {
        $oneDriveStatus = 'UNAVAILABLE'
        $oneDriveReason = "Sync helper missing: $helper"
        Write-Err $oneDriveReason
    }

    $script:OneDriveEvidenceStatus = $oneDriveStatus
    $script:OneDriveUnavailableReason = $oneDriveReason
    $script:OneDriveEvidencePath = $oneDriveDest
    Update-LiveEvidenceSummary -Outcome $Outcome -Stage 'FINALIZE' -SummaryText $SummaryText

    Write-OK "USB evidence exported: $usbDest"
    Write-Info "Outcome: $Outcome"
    Write-Info "OneDriveEvidenceStatus: $oneDriveStatus"
    if ($oneDriveReason) { Write-Info "OneDriveUnavailableReason: $oneDriveReason" }
}

Write-Banner "LAB LANE 1 - FleetMGR Verified Run [$RunId]"
Write-Info "Package : $PkgRoot"
Write-Info "Computer: $Computer"
Write-Info "RunId   : $RunId"
Write-Info $CanonicalNote
Write-Info $NoSyncNote
Initialize-LiveEvidenceBootstrap

if (-not (Test-Path -LiteralPath $PkgRoot)) {
    $msg = "ABORT - canonical package path not found: $PkgRoot"
    Write-Err $msg
    Export-Evidence -Outcome 'ABORT-NO-CANONICAL-PATH' -SummaryText "$msg`n$CanonicalNote"
    exit 1
}
if (-not $UsbVolume -or -not $UsbVolume.DriveLetter -or $UsbVolume.FileSystemLabel -ine 'LABBUILD') {
    $msg = "ABORT - package root is not on LABBUILD volume: $PkgRoot"
    Write-Err $msg
    Export-Evidence -Outcome 'ABORT-NON-LABBUILD-PATH' -SummaryText "$msg`n$CanonicalNote"
    exit 1
}

if ($BootstrapSelfTest) {
    $msg = 'Bootstrap self-test completed before installer/precheck/deployment blocks.'
    Write-RunLog -Level 'INFO' -Message $msg
    Update-LiveEvidenceSummary -Outcome 'BOOTSTRAP_SELFTEST_PASS' -Stage 'BOOTSTRAP_SELFTEST' -SummaryText $msg
    Write-OK $msg
    exit 0
}

Write-Banner "PRECHECK - Remote management bootstrap"
$remoteBootstrap = Enable-RemoteManagementBootstrap
$script:ServiceControlExecuted = $true
Write-Info $remoteBootstrap

Write-Banner "BLOCK 1 - Verify task scripts"
$required = @(
    'ChknMiner-Updater-Agent.ps1',
    'ChknMiner-BotRules.ps1',
    'ChknMiner-Condition-Monitor.ps1'
)
$missing = @()
foreach ($f in $required) {
    $p = Join-Path $PkgRoot $f
    if (Test-Path $p) {
        $item = Get-Item $p
        Write-OK "$f  ($([math]::Round($item.Length/1KB,1)) KB, $($item.LastWriteTime.ToString('yyyy-MM-dd HH:mm')))"
    } else {
        Write-Err "MISSING: $f"
        $missing += $f
    }
}
if ($missing.Count -gt 0) {
    $msg = "ABORT - $($missing.Count) required task script(s) missing from $PkgRoot`n" + ($missing -join "`n")
    Write-Err $msg
    Export-Evidence -Outcome 'ABORT-MISSING-SCRIPTS' -SummaryText $msg
    exit 1
}
Write-OK "All 3 task scripts present. Proceeding to installer."


Write-Banner "BLOCK 2 - Run installer"
$entryScript = Join-Path $PkgRoot 'Run This First.ps1'
if (-not (Test-Path $entryScript)) {
    $msg = "ABORT - 'Run This First.ps1' not found at $entryScript"
    Write-Err $msg
    Export-Evidence -Outcome 'ABORT-NO-ENTRY-SCRIPT' -SummaryText $msg
    exit 1
}
Write-Info "Launching: $entryScript"
Write-Info "Using subprocess with -ExecutionPolicy Bypass"
Set-Location $PkgRoot
$script:InstallerStartTime = Get-Date
$script:InstallerExecuted = $true
Write-RunLog -Level 'INFO' -Message ("Installer start at {0}" -f $script:InstallerStartTime.ToString('o'))
Update-LiveEvidenceSummary -Outcome 'INSTALLER_STARTED' -Stage 'INSTALLER_START' -SummaryText ("Launching installer: {0}" -f $entryScript)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File $entryScript
$script:installerExit = $LASTEXITCODE
Update-LiveEvidenceSummary -Outcome 'INSTALLER_EXIT' -Stage 'INSTALLER_EXIT' -SummaryText ("Installer exited with code: {0}" -f $script:installerExit)
Write-Info "Installer exited with code: $script:installerExit"
Start-Sleep -Seconds 3

# CADET: Stale proof/nonzero installer PASS prevention
$proofIsStale = $false
if (Test-Path $ProofPath) {
    $proofInfo = Get-Item $ProofPath
    if ($proofInfo.LastWriteTime -lt $script:InstallerStartTime) {
        $proofIsStale = $true
    }
}

Write-Banner "BLOCK 3 - Proof collection"
$summaryLines = @()
$summaryLines += "LAB LANE 1 RUN SUMMARY"
$summaryLines += "RunId   : $RunId"
$summaryLines += "Host    : $Computer"
$summaryLines += "Time    : $(Get-Date -Format 'o')"
$summaryLines += "PkgRoot : $PkgRoot"
$summaryLines += ""


if (-not (Test-Path $ProofPath)) {
    $summaryLines += "WARNING: Proof file not found at $ProofPath"
    $summaryLines += "Installer may not have run to completion."
    Write-Err "Proof file missing: $ProofPath"
    $summary = $summaryLines -join "`n"
    Export-Evidence -Outcome 'NO-PROOF' -SummaryText $summary
    exit 1
}
if ($script:installerExit -ne 0) {
    $summaryLines += "BLOCKER: INSTALLER_EXIT_CODE_$script:installerExit"
    Write-Err "Installer exited with nonzero code: $script:installerExit"
    $summary = $summaryLines -join "`n"
    Export-Evidence -Outcome "INSTALLER_EXIT_CODE_$script:installerExit" -SummaryText $summary
    exit $script:installerExit
}
if ($proofIsStale) {
    $summaryLines += "BLOCKER: STALE_PROOF_USED"
    Write-Err "Stale proof detected: $ProofPath"
    $summary = $summaryLines -join "`n"
    Export-Evidence -Outcome "STALE_PROOF_USED" -SummaryText $summary
    exit 2
}

try {
    $proof  = Get-Content $ProofPath -Raw | ConvertFrom-Json
    $stages = @($proof.Stages)
    $passed = @($stages | Where-Object { $_.Success })
    $failed = @($stages | Where-Object { -not $_.Success })
    $blockers = New-Object System.Collections.Generic.List[string]

    $summaryLines += "ProofRunId : $($proof.RunId)"
    $summaryLines += "Generated  : $($proof.GeneratedAt)"
    $summaryLines += "RESULT     : $($passed.Count) passed / $($failed.Count) failed / $($stages.Count) total"
    $summaryLines += ""

    $step6 = @($stages | Where-Object { $_.Step -in @('Step6-UpdaterAgent','Updater-Agent') })
    $step7 = @($stages | Where-Object { $_.Step -match 'Step7-BotRules|Step7-ConditionMonitor|BotRules|ConditionMonitor|Condition-Monitor' })
    $step6Pass = (@($step6 | Where-Object { $_.Success }).Count -gt 0)
    $step7Pass = ($step7 | Where-Object { $_.Success }).Count -eq $step7.Count -and $step7.Count -gt 0

    $summaryLines += "Step 6 (Updater-Agent task)   : $(if($step6Pass){'PASS'}else{'FAIL/MISSING'})"
    $summaryLines += "Step 7 (BotRules+Condition)   : $(if($step7Pass){'PASS'}else{'FAIL/MISSING'})"
    if (-not $step6Pass) { $blockers.Add('STEP6_FAIL_OR_MISSING') | Out-Null }
    if (-not $step7Pass) { $blockers.Add('STEP7_FAIL_OR_MISSING') | Out-Null }
    $summaryLines += ""

    $runThisFirstOutcome = Get-ChildItem -Path $script:UsbEvidencePath -File -Filter ("run-this-first-outcome-{0}-*.json" -f $Computer) -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if (-not $runThisFirstOutcome) {
        $summaryLines += "BLOCKER: MISSING_RUN_THIS_FIRST_OUTCOME_JSON"
        $blockers.Add('MISSING_RUN_THIS_FIRST_OUTCOME_JSON') | Out-Null
    } else {
        try {
            $rtfObj = Get-Content -LiteralPath $runThisFirstOutcome.FullName -Raw | ConvertFrom-Json -ErrorAction Stop
            $summaryLines += "RunThisFirstOutcome: $($runThisFirstOutcome.Name)"
            if ($null -eq $rtfObj.ChildExitCode) {
                $summaryLines += "BLOCKER: RUN_THIS_FIRST_CHILD_EXIT_MISSING"
                $blockers.Add('RUN_THIS_FIRST_CHILD_EXIT_MISSING') | Out-Null
            } elseif ($script:installerExit -ne [int]$rtfObj.ChildExitCode) {
                $summaryLines += "BLOCKER: INSTALLER_EXIT_CONFLICT launcher=$script:installerExit run-this-first=$($rtfObj.ChildExitCode)"
                $blockers.Add('INSTALLER_EXIT_CONFLICT') | Out-Null
            }
            if (-not $rtfObj.ChildFinalStatusPresent) {
                $summaryLines += "BLOCKER: CHILD_FINAL_STATUS_MISSING"
                $blockers.Add('CHILD_FINAL_STATUS_MISSING') | Out-Null
            }
        } catch {
            $summaryLines += "BLOCKER: RUN_THIS_FIRST_OUTCOME_PARSE_ERROR"
            $blockers.Add('RUN_THIS_FIRST_OUTCOME_PARSE_ERROR') | Out-Null
        }
    }

    foreach ($requiredRunLocal in @('compliance-inventory.json','chknminer-condition-state.json','thread-control.json')) {
        if (-not (Test-Path -LiteralPath (Join-Path $script:UsbEvidencePath $requiredRunLocal))) {
            $summaryLines += "BLOCKER: MISSING_RUN_LOCAL_EXPORT $requiredRunLocal"
            $blockers.Add("MISSING_RUN_LOCAL_EXPORT_$requiredRunLocal") | Out-Null
        }
    }

    if ($failed.Count -gt 0) {
        $summaryLines += "--- FAILED STAGES ---"
        foreach ($s in $failed) {
            $summaryLines += "  Step : $($s.Step)"
            $summaryLines += "  Detail: $($s.Detail | ConvertTo-Json -Depth 3 -Compress)"
            $summaryLines += ""
        }
    } else {
        $summaryLines += "No failed stages."
    }

    $runtimeLogs = Get-ChildItem 'C:\ProgramData\LabDeploy' -Recurse -Include *.log,*.txt,*.json -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 50
    $oneDriveStatus = if (Get-OneDriveRoot) { 'PRESENT' } else { 'UNAVAILABLE' }
    $compliancePath = Write-ComplianceInventory -PkgRoot $PkgRoot -Proof $proof -SmokePath $ProofPath -XmrigStatus 'WINDOWS_XMRIG_DOWNLOAD_BLOCKED' -ProofPath $ProofPath -RuntimeLogPaths @($runtimeLogs | ForEach-Object { $_.FullName }) -UsbEvidencePath $script:UsbEvidencePath -OneDriveEvidenceStatus $oneDriveStatus
    $summaryLines += ""
    $summaryLines += "ComplianceInventory: $compliancePath"
    if (Test-Path -LiteralPath $compliancePath) {
        $complianceInfo = Get-Item -LiteralPath $compliancePath
        if ($complianceInfo.LastWriteTime -lt $script:InstallerStartTime) {
            $summaryLines += "BLOCKER: STALE_COMPLIANCE_USED"
            Write-Err "Stale compliance detected: $compliancePath"
            $summary = $summaryLines -join "`n"
            Export-Evidence -Outcome "STALE_COMPLIANCE_USED" -SummaryText $summary
            exit 3
        }
    } else {
        $summaryLines += "BLOCKER: NO_COMPLIANCE_ARTIFACT"
        Write-Err "Compliance inventory missing: $compliancePath"
        $summary = $summaryLines -join "`n"
        Export-Evidence -Outcome "NO_COMPLIANCE_ARTIFACT" -SummaryText $summary
        exit 4
    }
    if ($script:ServiceControlExecuted -and -not $script:ServiceControlPolicyApproved) {
        $summaryLines += "BLOCKER: SERVICE_CONTROL_POLICY_NOT_APPROVED"
        $blockers.Add('SERVICE_CONTROL_POLICY_NOT_APPROVED') | Out-Null
    }
    if ($failed.Count -eq 0 -and $step6Pass -and $step7Pass) {
        if ($summaryLines -contains 'No failed stages.') {
            # Keep aggregate statement only when stage-level checks also passed.
        }
    } elseif ($summaryLines -contains 'No failed stages.') {
        $summaryLines += "NOTE: Aggregate stage summary conflicted with stage-level checks."
    }
    if ($blockers.Count -gt 0) {
        $summaryLines += ""
        $summaryLines += "--- BLOCKERS ---"
        foreach ($b in $blockers) { $summaryLines += "  $b" }
    }
    $summaryLines | ForEach-Object { Write-Host $_ }
    $outcome = if ($failed.Count -eq 0 -and $blockers.Count -eq 0) { 'PASS' } else { 'FAIL' }
    Export-Evidence -Outcome $outcome -SummaryText ($summaryLines -join "`n")
} catch {
    $msg = "ERROR reading proof file: $_"
    Write-Err $msg
    Export-Evidence -Outcome 'PROOF-READ-ERROR' -SummaryText $msg
    exit 1
}

Write-Banner "LAB LANE 1 COMPLETE - paste RESULT line to agent"
