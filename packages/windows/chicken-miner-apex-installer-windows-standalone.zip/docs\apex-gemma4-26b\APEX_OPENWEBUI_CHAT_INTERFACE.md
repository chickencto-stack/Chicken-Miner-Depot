﻿# APEX OpenWebUI Chat Interface

- External URL: http://10.0.0.27:3000
- UI status from this lane: reachable (HTTP 200)
- OpenWebUI models API status from this lane: HTTP 401 (login required)
- Internal provider target expected: http://gemma-vllm:8000/v1
- Expected model in UI: /models/26b

## Human-required validation
1. Open http://10.0.0.27:3000
2. Sign in with authorized operator account
3. Confirm /models/26b is selectable
4. Send: Reply with APEX_GEMMA4_26B_CHAT_READY only.
5. Confirm exact response: APEX_GEMMA4_26B_CHAT_READY

No auth bypass, no secret disclosure.
