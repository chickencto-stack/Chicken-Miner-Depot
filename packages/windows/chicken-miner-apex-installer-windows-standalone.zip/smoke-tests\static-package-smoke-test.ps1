# READ_ONLY: static package inspection only. Does not start services or models.
$ErrorActionPreference = 'Stop'
if(-not (Test-Path '.\MANIFEST.json')) { throw 'MANIFEST.json missing' }
if(-not (Test-Path '.\graph_context\APEX_CODEGRAPHCONTEXT_HANDOFF.md')) { throw 'Graph context handoff missing' }
if(-not (Test-Path '.\SHA256SUMS.txt')) { throw 'SHA256SUMS.txt missing' }
Write-Output 'STATIC_PACKAGE_READY'
